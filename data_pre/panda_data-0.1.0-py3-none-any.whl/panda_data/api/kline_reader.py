from typing import Optional, Union
import pandas as pd
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config

def get_stock_detail(symbol: str,fields: Optional[list] = None) -> pd.DataFrame:
    """
    获取指定股票的详细信息。

    参数：
        symbol (str): 股票代码，必填。
        fields (list, 可选): 需要返回的字段列表，默认为None返回全部字段。

    返回：
        pd.DataFrame: 指定股票的详细信息，字段由fields决定。
    """
    if not symbol:
        raise ValueError("symbol不能为空")
    query = {
        "symbol": symbol
    }
    db_handler = DatabaseHandler(config)

    projection = None
    if fields:
        if "symbol" not in fields:
            fields.append("symbol")
        projection = {field: 1 for field in fields}
    projection["_id"] = 0
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "stock_symbol", query,projection))
    # 排除symbol为'UNKNOWN'的数据
    if not result.empty and "symbol" in result.columns:
        result = result[result["symbol"].str.upper() != "UNKNOWN"]
    return result

def get_all_symbols(market: str = "cn"):
    """
       获取所有股票代码

       参数:
           market (str): 市场类型，可选值为 "cn"（A股）、"hk"（港股）、"us"（美股），默认为 "cn"

       返回:
           pd.DataFrame: 包含所有股票代码的DataFrame，按symbol升序排列
       """
    # 验证市场参数
    if market not in ["cn", "hk", "us"]:
        raise ValueError(f"market 参数错误，应为 'cn'、'hk' 或 'us'，当前值: {market}")
    
    # 根据市场类型选择集合名称
    if market == "cn":
        collection_name = "stock_symbol"
    elif market == "hk":
        collection_name = "stock_symbol_hk"
    else:  # market == "us"
        collection_name = "stock_symbol_us"
    
    query = {}
    db_handler = DatabaseHandler(config)
    projection = {
        "_id": 0,
        "symbol": 1
    }
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], collection_name, query, projection))
    # 排序：按symbol升序
    if not result.empty and "symbol" in result.columns:
        result = result.sort_values(by="symbol", ascending=True)
        result = result.reset_index(drop=True)
    return result


def get_market_data(symbol: Optional[Union[str, list]] = "",
                    start_date: Optional[str] = "",
                    end_date: Optional[str] = "",
                    symbol_type: Optional[str] = "stock",
                    fields: Optional[list] = None,
                    index_component: Optional[str] = None) -> pd.DataFrame:
    """
    获取产品（日线）行情数据。

    参数：
        symbol (str 或 list, 可选): 产品代码，可以是单个代码字符串或代码列表，如股票、期货、指数代码，默认为空，返回所有。
        start_date (str, 可选): 起始日期，格式为"YYYYMMDD"，默认为空。
        end_date (str, 可选): 结束日期，格式为"YYYYMMDD"，默认为空。
        symbol_type (str, 可选): 产品类型，可选值为"stock"（股票）、"future"（期货）、"index"（指数），默认为"stock"。
        fields (list, 可选): 需要返回的字段列表，默认为None返回全部字段。
        index_component (str, 可选): 指数成分股筛选，仅在symbol_type为"stock"时有效，默认为None。

    返回：
        pd.DataFrame: 满足条件的产品行情数据，按日期降序排列。
    """
    query = {}
    if symbol:
        if isinstance(symbol, list):
            # 如果symbol是列表，使用$in操作符
            query["symbol"] = {"$in": symbol}
        else:
            # 如果symbol是字符串，直接匹配
            query["symbol"] = symbol
    if start_date:
        query["date"] = {"$gte": start_date}
    if end_date:
        if "date" in query:
            query["date"]["$lte"] = end_date
        else:
            query["date"] = {"$lte": end_date}
    
    # 添加指数成分股筛选条件（仅在symbol_type为stock时有效）
    if index_component and symbol_type == "stock":
        query["index_component"] = index_component
    
    db_handler = DatabaseHandler(config)
    projection = None
    if fields:
        # 确保 symbol 和 date 一定在返回字段中
        for must_field in ["symbol", "date"]:
            if must_field not in fields:
                fields.append(must_field)
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    if symbol_type == "future":
        result = db_handler.mongo_find(config["MONGO_DB"], "future_market", query,projection)
    elif symbol_type == "stock":
        result = db_handler.mongo_find(config["MONGO_DB"], "stock_market", query,projection)
    elif symbol_type == "index":
        result = db_handler.mongo_find(config["MONGO_DB"], "index_market", query,projection)
    else:
        raise ValueError(f"错误的产品类型: {symbol_type}")
    df = pd.DataFrame(result)
    # 排序：先按symbol升序，再按date降序
    if not df.empty and "date" in df.columns:
        df = df.sort_values(by=["symbol","date"], ascending=[True,False])
        df = df.reset_index(drop=True)
    return df


def get_market_min_data(symbol: Optional[Union[str, list]] = "",
                        start_date: Optional[str] = "",
                        end_date: Optional[str] = "",
                        symbol_type: Optional[str] = "stock",
                        fields: Optional[list] = None,
                        time_zone: Optional[tuple] = None) -> pd.DataFrame:
    """
    获取产品（分钟线）行情数据。

    参数：
        symbol (str 或 list, 可选): 产品代码，可以是单个代码字符串或代码列表，如股票、期货代码，默认为空，返回所有。
        start_date (str, 可选): 起始日期，格式为"YYYYMMDD"，默认为空。
        end_date (str, 可选): 结束日期，格式为"YYYYMMDD"，默认为空。
        symbol_type (str, 可选): 产品类型，可选值为"stock"（股票）、"future"（期货），默认为"stock"。
        fields (list, 可选): 需要返回的字段列表，默认为None返回全部字段。
        time_zone (tuple, 可选): 时间段过滤，格式为("HH:MM", "HH:MM")，例如("10:00", "23:00")，默认为None返回全部时间。

    返回：
        pd.DataFrame: 满足条件的产品分钟行情数据，按日期降序排列。
    """
    from datetime import datetime, timedelta
    query = {}
    if symbol:
        if isinstance(symbol, list):
            # 如果symbol是列表，使用$in操作符
            query["symbol"] = {"$in": symbol}
        else:
            # 如果symbol是字符串，直接匹配
            query["symbol"] = symbol
    date_query = {}
    if start_date:
        start_dt = datetime.strptime(start_date, "%Y%m%d")
        date_query["$gte"] = start_dt
    if end_date:
        end_dt = datetime.strptime(end_date, "%Y%m%d")
        end_dt = end_dt + timedelta(days=1) - timedelta(seconds=1)
        date_query["$lte"] = end_dt
    if date_query:
        query["date"] = date_query
    db_handler = DatabaseHandler(config)
    projection = None
    if fields:
        # 确保 symbol 和 date 一定在返回字段中
        for must_field in ["symbol", "date"]:
            if must_field not in fields:
                fields.append(must_field)
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    else:
        projection = {"_id": 0}  # 如果不指定 fields，默认不返回 _id 字段
    if symbol_type == "stock":
        result = db_handler.mongo_find(config["MONGO_DB"], "stock_1m_market", query,projection)
    elif symbol_type == "future":
        result = db_handler.mongo_find(config["MONGO_DB"], "future_1m_market", query,projection)
    elif symbol_type == "index":
        result = db_handler.mongo_find(config["MONGO_DB"], "index_1m_market", query,projection)
    else:
        raise ValueError(f"错误的产品类型: {symbol_type}")
    df = pd.DataFrame(result)
    
    # 如果指定了时间段过滤，则进行时间过滤
    if time_zone and not df.empty and "date" in df.columns:
        try:
            start_time_str, end_time_str = time_zone
            # 解析时间字符串
            start_hour, start_minute = map(int, start_time_str.split(":"))
            end_hour, end_minute = map(int, end_time_str.split(":"))
            
            # 创建时间过滤条件
            def is_in_time_zone(dt):
                if pd.isna(dt):
                    return False
                time_part = dt.time()
                start_time = datetime.min.replace(hour=start_hour, minute=start_minute).time()
                end_time = datetime.min.replace(hour=end_hour, minute=end_minute).time()
                
                # 处理跨天的情况（如23:00到次日02:00）
                if start_time <= end_time:
                    return start_time <= time_part <= end_time
                else:
                    return time_part >= start_time or time_part <= end_time
            
            # 应用时间过滤
            df = df[df['date'].apply(is_in_time_zone)]
            df = df.reset_index(drop=True)
            
        except (ValueError, TypeError) as e:
            raise ValueError(f"time_zone参数格式错误，应为('HH:MM', 'HH:MM')格式，例如('10:00', '23:00'): {e}")
    
    # 排序：先按symbol升序，再按date降序
    if not df.empty and "date" in df.columns:
        df = df.sort_values(by=["symbol", "date"], ascending=[True, False])
        df = df.reset_index(drop=True)
    return df




