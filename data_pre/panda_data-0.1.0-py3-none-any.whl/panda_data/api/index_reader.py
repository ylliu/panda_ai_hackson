from typing import Optional, Union, List
import pandas as pd
from ..common.handlers.database_handler import DatabaseHandler
from ..common.handlers.parquet_handler import ParquetHandler
from ..common.config import config
from ..common.parquet_path import INDEX_COMPONENT_US


def get_index_symbol(
        symbol: Optional[Union[str, List[str]]] = None,
        status: Optional[int] = None,
        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取指数基本信息
    
    Args:
        symbol: 指数代码，如 "000001.SH" 或 ["000001.SH", "000002.SH"]，默认为None返回所有
        status: 指数状态，1=活跃，0=退市，-1=未知，默认为None返回所有状态
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含指数基本信息的DataFrame
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if symbol:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol
    if status is not None:
        query['status'] = status
    
    # 构建投影
    projection = None
    if fields:
        if "symbol" not in fields:
            fields.append("symbol")
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0
    
    # 执行查询
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "index_symbol", query, projection))

    # 排除symbol为'UNKNOWN'的数据，按symbol升序
    if not result.empty and "symbol" in result.columns:
        result = result[result["symbol"].str.upper() != "UNKNOWN"]
        result = result.sort_values(by="symbol", ascending=True)
        result = result.reset_index(drop=True)
    
    return result



def get_index_indicator(symbol: Optional[Union[str, List[str]]] = None,
                        start_date: Optional[str] = None,
                        end_date: Optional[str] = None,
                        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取指数估值指标数据
    
    Args:
        symbol: 指数代码，如 "000001.SH" 或 ["000001.SH", "000002.SH"]，默认为None返回所有
        start_date: 开始日期，格式 "YYYYMMDD"，默认为None
        end_date: 结束日期，格式 "YYYYMMDD"，默认为None
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含指数估值指标数据的DataFrame，按日期降序排列
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if symbol:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol
    if start_date:
        query['date'] = {'$gte': start_date}
    if end_date:
        if 'date' in query:
            query['date']['$lte'] = end_date
        else:
            query['date'] = {'$lte': end_date}
    
    # 构建投影
    projection = None
    if fields:
        # 确保 symbol 和 date 一定在返回字段中
        for must_field in ["symbol", "date"]:
            if must_field not in fields:
                fields.append(must_field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0
    
    # 执行查询
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "index_indicator", query, projection))
    
    # 排序: 先按symbol升序，再按date降序
    if not result.empty and "symbol" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["symbol","date"], ascending=[True, False])
        result = result.reset_index(drop=True)

    return result


def get_index_weights(
                     index_symbol: Optional[Union[str, List[str]]] = None, 
                     stock_symbol: Optional[Union[str, List[str]]] = None,
                     start_date: Optional[str] = None, end_date: Optional[str] = None, 
                     fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取指数权重数据
    
    Args:
        index_symbol: 指数代码，如 "000001.SH" 或 ["000001.SH", "000002.SH"]，默认为None返回所有
        stock_symbol: 股票代码，如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，默认为None返回所有
        start_date: 开始日期，格式 "YYYYMMDD"，默认为None
        end_date: 结束日期，格式 "YYYYMMDD"，默认为None
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含指数权重数据的DataFrame，按日期降序排列
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if index_symbol:
        if isinstance(index_symbol, list):
            query['index_symbol'] = {'$in': index_symbol}
        else:
            query['index_symbol'] = index_symbol
    if stock_symbol:
        if isinstance(stock_symbol, list):
            query['stock_symbol'] = {'$in': stock_symbol}
        else:
            query['stock_symbol'] = stock_symbol
    if start_date:
        query['date'] = {'$gte': start_date}
    if end_date:
        if 'date' in query:
            query['date']['$lte'] = end_date
        else:
            query['date'] = {'$lte': end_date}
    
    # 构建投影
    projection = None
    if fields:
        # 确保关键字段一定在返回字段中
        for must_field in ["date", "index_symbol", "stock_symbol"]:
            if must_field not in fields:
                fields.append(must_field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0
    
    # 执行查询
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "index_weights", query, projection))
    
    # 排序: 先按index_symbol,升序，再按date降序
    if not result.empty and "index_symbol" in result and "stock_symbol" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["index_symbol","stock_symbol","date"], ascending=[True,True,False])
        result = result.reset_index(drop=True)
    return result


# def get_index_stock(symbol: Optional[Union[str, List[str]]] = None,
#                     start_date: Optional[str] = None,
#                     end_date: Optional[str] = None) -> pd.DataFrame:
#     """
#     获取指数成分股信息
#
#     Args:
#         symbol: 指数代码，如 "000001.SH" 或 ["000001.SH", "000002.SH"]
#         start_date: 开始日期，格式 "YYYYMMDD"
#         end_date: 结束日期，格式 "YYYYMMDD"
#
#     Returns:
#         DataFrame: 包含指数成分股信息的DataFrame
#     """
#     # 调用权重数据接口，返回成分股信息
#     return get_index_weights(index_symbol=symbol, start_date=start_date, end_date=end_date)

def get_index_stock(symbol: Optional[Union[str, List[str]]] = None,
                    start_date: Optional[str] = None,
                    end_date: Optional[str] = None) -> pd.DataFrame:
    """
        获取指数成分股信息

        Args:
            symbol: 指数代码，如 "000001.SH" 或 ["000001.SH", "000002.SH"]
            start_date: 开始日期，格式 "YYYYMMDD"
            end_date: 结束日期，格式 "YYYYMMDD"

        Returns:
            DataFrame: 包含指数成分股信息的DataFrame
        """
    return get_index_weights(index_symbol=symbol, start_date=start_date, end_date=end_date)


def get_index_component_us(
        index_symbol: Union[str, List[str]],
        stock_symbol: Optional[Union[str, List[str]]] = None,
        date: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取美股指数成分股数据（parquet 数据源）

    Args:
        index_symbol: 指数代码，如 "NDX.GI" 或 ["NDX.GI", "SPX.GI"]，必填
        stock_symbol: 成分股代码，如 "AAPL.O" 或 ["AAPL.O", "MSFT.O"]
        date: 交易日期，格式 "YYYYMMDD"，与 start_date/end_date 不能同时指定
        start_date: 开始日期，格式 "YYYYMMDD"，必须与 end_date 同时指定，且不能与 date 同时指定
        end_date: 结束日期，格式 "YYYYMMDD"，必须与 start_date 同时指定，且不能与 date 同时指定
        fields: 需要返回的字段列表，默认为None返回全部字段

    Returns:
        DataFrame: 包含美股指数成分股信息的DataFrame，按 index_symbol、date 降序排序
    """
    # 验证 index_symbol 必填
    if index_symbol is None or (isinstance(index_symbol, (list, tuple, set)) and len(index_symbol) == 0):
        raise ValueError("index_symbol 为必填参数，且不能为空。")
    
    # 验证日期参数：date 和 start_date/end_date 不能同时指定
    has_date = date is not None
    has_start_date = start_date is not None
    has_end_date = end_date is not None
    
    if has_date and (has_start_date or has_end_date):
        raise ValueError("date 与 start_date/end_date 不能同时指定。")
    
    if has_start_date != has_end_date:
        raise ValueError("start_date 和 end_date 必须同时指定。")
    
    if not has_date and not has_start_date:
        raise ValueError("必须指定 date 或同时指定 start_date 和 end_date。")

    parquet_path = INDEX_COMPONENT_US

    parquet_handler = ParquetHandler(parquet_path)

    columns = None
    if fields:
        columns = list(fields)
        for required in ["index_symbol", "stock_symbol", "date"]:
            if required not in columns:
                columns.append(required)

    def _normalize_to_list(value: Optional[Union[str, List[str]]]) -> Optional[List[str]]:
        if value is None:
            return None
        if isinstance(value, (list, tuple, set)):
            return [str(v) for v in value]
        return [str(value)]

    index_symbols = _normalize_to_list(index_symbol)
    stock_symbols = _normalize_to_list(stock_symbol)

    def _build_in_condition(column: str, values: Optional[List[str]]) -> Optional[str]:
        if not values:
            return None
        sanitized = [str(v).replace("'", "''") for v in values]
        joined = "', '".join(sanitized)
        return f"{column} IN ('{joined}')"

    conditions: List[str] = []
    index_condition = _build_in_condition("index_symbol", index_symbols)
    if index_condition:
        conditions.append(index_condition)
    stock_condition = _build_in_condition("stock_symbol", stock_symbols)
    if stock_condition:
        conditions.append(stock_condition)

    # 根据日期参数决定查询范围
    if has_date:
        query_start_date = str(date)
        query_end_date = str(date)
    else:
        query_start_date = str(start_date)
        query_end_date = str(end_date)

    result = parquet_handler.query_data(
        start_date=query_start_date,
        end_date=query_end_date,
        columns=columns,
        symbols=None,
        custom_conditions=conditions
    )

    if result.empty:
        return result

    sort_cols = [col for col in ["index_symbol", "date", "stock_symbol"] if col in result.columns]
    if sort_cols:
        ascending = [True if col != "date" else False for col in sort_cols]
        result = result.sort_values(by=sort_cols, ascending=ascending)
        result = result.reset_index(drop=True)

    return result



def get_index_list(status: Optional[int] = None) -> pd.DataFrame:
    """
    获取指数列表
    
    Args:
        status: 状态参数，1=活跃，0=退市，-1=未知，默认为None返回所有状态
    
    Returns:
        DataFrame: 指数列表
    """
    # 调用指数基本信息接口
    return get_index_symbol(status=status)


def get_all_index_symbols() -> pd.DataFrame:
    """
    获取所有指数代码
    
    Returns:
        DataFrame: 包含所有指数代码的DataFrame
    """
    return get_index_symbol(fields=["symbol", "name", "status"])


def get_index_1m_market(symbol: Optional[Union[str, List[str]]] = None, start_date: Optional[str] = None,
                        end_date: Optional[str] = None, time_zone: Optional[tuple] = None,
                        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取指数1分钟级行情数据
    
    Args:
        symbol: 指数代码，如 "000001.SH" 或 ["000001.SH", "000002.SH"]，默认为None返回所有
        start_date: 开始日期，格式 "YYYYMMDD"，默认为None
        end_date: 结束日期，格式 "YYYYMMDD"，默认为None
        time_zone: 时间段过滤，格式为("HH:MM", "HH:MM")，例如("10:00", "23:00")，默认为None
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含指数1分钟级行情数据的DataFrame，按日期和时间降序排列
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if symbol:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol
    if start_date:
        query['trading_date'] = {'$gte': start_date}
    if end_date:
        if 'trading_date' in query:
            query['trading_date']['$lte'] = end_date
        else:
            query['trading_date'] = {'$lte': end_date}
    # 处理time_zone参数
    if time_zone:
        if len(time_zone) != 2:
            raise ValueError("time_zone参数必须是一个包含两个元素的元组，格式为('HH:MM', 'HH:MM')")
        
        start_timezone, end_timezone = time_zone
        
        # 将HH:MM格式转换为HHMM格式
        def time_to_hhmm(time_str):
            if ':' in time_str:
                return time_str.replace(':', '')
            return time_str
        
        start_hhmm = time_to_hhmm(start_timezone)
        end_hhmm = time_to_hhmm(end_timezone)
        
        # 由于数据库中的date字段是ISODate格式，我们需要使用$expr和$dateToString来提取时间部分
        # 如果timezone跨越了午夜（如23:00到01:00），需要特殊处理
        if start_hhmm > end_hhmm:
            # 跨午夜的情况，使用$or条件
            query['$or'] = [
                {'$expr': {'$and': [
                    {'$gte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, start_hhmm]},
                    {'$lte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, '2359']}
                ]}},
                {'$expr': {'$and': [
                    {'$gte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, '0000']},
                    {'$lte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, end_hhmm]}
                ]}}
            ]
        else:
            # 正常情况，在同一天内
            query['$expr'] = {'$and': [
                {'$gte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, start_hhmm]},
                {'$lte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, end_hhmm]}
            ]}
    
    # 构建投影
    projection = None
    if fields:
        # 确保关键字段一定在返回字段中
        for must_field in ["symbol", "trading_date", "date"]:
            if must_field not in fields:
                fields.append(must_field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0
    
    # 执行查询
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "index_1m_market", query, projection))
    
    # 排序：先按symbol升序，trading_date降序、date升序序
    if not result.empty and "symbol" in result.columns and "trading_date" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["symbol","trading_date", "date"], ascending=[True, False, True])
        result = result.reset_index(drop=True)
    
    return result
