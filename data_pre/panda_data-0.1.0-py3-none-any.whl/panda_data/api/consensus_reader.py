import pandas as pd
import re
from typing import Optional, Union, List
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_consensus_report(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None,
        rating: Optional[List[str]] = None,
        quarter_limit: Optional[int] = None
) -> pd.DataFrame:
    """
    从 consensus_report 集合中读取数据，支持带后缀字段匹配、rating字段特殊处理及期数限制

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的基础字段列表（用户输入原始字段名，如roe、op_rt等，可选）
        rating: 指定返回的rating子字段列表（如["MaiRu", "YouYuDaShi"]，可选，仅当fields包含rating时生效）
        quarter_limit: 带后缀字段的期数上限（如3则返回T、T_1、T_2，可选）

    返回:
        包含查询结果的DataFrame，确保包含symbol和date字段
    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 带后缀的原始字段（需匹配T、T_1等后缀）
    SUFFIXED_FIELDS = {'quarter', 'op_rt', 'op_pr', 'tp', 'np', 'eps', 'pe', 'rd', 'ev_ebitda', 'roe'}
    # 非rating的已知固定字段（用于排除法筛选rating类字段）
    OTHER_KNOWN_FIELDS = {
        '_id', 'report_date', 'report_title', 'name', 'classify', 'author_name', 'org_name', 'max_price', 'min_price',
        'symbol'}
    query = {}

    # 处理symbol - 修复空值处理逻辑
    if symbol is not None:
        # 处理列表情况
        if isinstance(symbol, list):
            # 过滤掉空字符串和None值
            filtered_symbols = [s for s in symbol if s is not None and s != '']
            if filtered_symbols:  # 只有当有过滤后的有效值时才添加查询条件
                query['symbol'] = {'$in': filtered_symbols}
            # 如果过滤后没有有效值，则不添加symbol查询条件，等同于查询所有symbol
        else:
            # 处理单个值情况
            if symbol != '':  # 空字符串不添加查询条件
                query['symbol'] = symbol
            # 空字符串则不添加symbol查询条件，等同于查询所有symbol

    # 处理日期范围
    date_query = {}
    if start_date is not None and start_date != '':
        date_query['$gte'] = start_date
    if end_date is not None and end_date != '':
        date_query['$lte'] = end_date
    if date_query:
        query['report_date'] = date_query

    db_handler = DatabaseHandler(config)
    # 仅排除_id，不限制其他字段（后续在DataFrame中筛选）
    result = db_handler.mongo_find(db_name=config["MONGO_DB"], collection_name="consensus_report", query=query,
                                   projection={'_id': 0})
    result_df = pd.DataFrame(result)
    if result_df.empty:
        return result_df

    # 处理fields为None的情况
    if fields is None:
        # fields为None时，默认需要所有字段
        target_suffix_fields = SUFFIXED_FIELDS  # 所有带后缀原始字段
        target_other_fields = [f for f in OTHER_KNOWN_FIELDS if f not in SUFFIXED_FIELDS]
        has_rating = True  # 包含所有rating字段
    else:
        # 过滤掉空字符串
        filtered_fields = [f for f in fields if f is not None and f != '']
        # 从输入fields中提取目标字段
        target_suffix_fields = [f for f in filtered_fields if f in SUFFIXED_FIELDS]
        target_other_fields = [f for f in filtered_fields if f not in SUFFIXED_FIELDS and f != 'rating']
        has_rating = 'rating' in filtered_fields  # 是否需要包含rating字段

    # 处理带后缀字段
    extended_suffix_cols = []
    for field in target_suffix_fields:
        # 过滤空字段
        if not field:
            continue
        # 正则匹配：字段名+T（+_数字），如op_rtT、op_rtT_1
        pattern = re.compile(f'^{re.escape(field)}T(_\\d+)?$')
        matching_cols = [col for col in result_df.columns if pattern.match(col)]

        # 按后缀排序（T -> T_1 -> T_2...）
        def sort_key(col):
            suffix = col.split('T', 1)[1]
            return 0 if not suffix else int(suffix.split('_')[1]) if suffix.startswith('_') else float('inf')

        sorted_cols = sorted(matching_cols, key=sort_key)

        # 期数限制
        if quarter_limit is not None:
            sorted_cols = sorted_cols[:quarter_limit]

        extended_suffix_cols.extend(sorted_cols)

    # 处理固定字段（非后缀、非rating的字段）
    other_cols = [col for col in target_other_fields if col in result_df.columns]

    # 处理rating字段（通过排除法筛选）
    rating_cols = []
    if has_rating:
        excluded_cols = set(OTHER_KNOWN_FIELDS) | set(extended_suffix_cols) | set(other_cols)
        all_rating_candidates = [col for col in result_df.columns if col not in excluded_cols]
        # 应用rating入参筛选（如指定["MaiRu"]则仅返回该字段）
        if rating is not None:
            # 过滤掉空字符串
            filtered_rating = [r for r in rating if r is not None and r != '']
            if filtered_rating:
                # 大小写不敏感匹配
                rating_lower = [r.lower() for r in filtered_rating]
                for col in all_rating_candidates:
                    if col.lower() in rating_lower:
                        rating_cols.append(col)
            else:
                rating_cols = all_rating_candidates  # 如果过滤后没有有效值，则返回所有rating字段
        else:
            rating_cols = all_rating_candidates  # 返回所有rating字段

    # 合并所有需要保留的字段（确保包含symbol和report_date）
    required_cols = ['symbol', 'report_date']  # 必含字段
    retained_cols = list(
        set(required_cols) | set(extended_suffix_cols) | set(other_cols) | set(rating_cols)
    )
    # 按存在性过滤（避免DataFrame中不存在的字段）
    valid_cols = [col for col in retained_cols if col in result_df.columns]
    final_df = result_df[valid_cols]

    required_cols = ["symbol", "report_date"]
    # # 排序：先按symbol升序，再按report_date降序
    if all(col in final_df.columns for col in required_cols):
        final_df = final_df.sort_values(by=required_cols, ascending=[True, False]).reset_index(drop=True)
    return final_df
