# import secrets
# import string
# import uuid
# from datetime import datetime
# import panda_data
# from panda_factor_server.models.request_body import CreateFactorRequest
# from panda_factor_server.services.user_factor_service import create_factor, run_factor
# from panda_data.common.logger_config import logger
# from typing import Optional, List, Union
# import pandas as pd
# from panda_factor.generate.macro_factor import MacroFactor
# from panda_data.common.handlers.database_handler import DatabaseHandler
# from panda_data.common.config import config
#
#
# def get_factor(factors: Union[str, List[str]], start_date: str, end_date: str,
#                symbol: Union[str, List[str]], index_component: Optional[str] = None,
# #               type: Optional[str] = 'stock') -> Optional[pd.DataFrame]:
#     """
#     获取基础因子数据。
#
#     参数：
#         factors (str 或 List[str]): 因子名称或因子名称列表。
#         start_date (str): 查询起始日期，格式如 '20230101'。
#         end_date (str): 查询结束日期，格式如 '20231231'。
#         symbols (str 或 List[str]): 股票/期货代码或代码列表。
#         index_component (Optional[str]): 成分指数代码，默认为 "001"。
#         type (Optional[str]): 标的类型，默认为 'stock'。
#
#     返回：
#         Optional[pd.DataFrame]: 查询到的因子数据表，若无数据则返回 None。
#     """
#     panda_data.init()
#     return panda_data.get_factor(factors, start_date=start_date, end_date=end_date, symbols=symbol, index_component=index_component, type=type)
#
# # def get_factor(symbol: Optional[Union[str, List[str]]] = None,
# #                factors: Optional[Union[str, List[str]]] = None,
# #                start_date: Optional[str] = "",
# #                end_date: Optional[str] = "",
# #                index_component: Optional[str] = None,
# #                symbol_type: Optional[str] = 'stock') -> Optional[pd.DataFrame]:
# #     """
# #     获取基础因子数据。
# #
# #     参数：
# #         symbols (str 或 List[str], 可选): 股票/期货代码或代码列表，默认为None，返回所有。
# #         factors (str 或 List[str], 可选): 因子名称或因子名称列表，默认为None，返回所有。
# #         start_date (str, 可选): 起始日期，格式为"YYYYMMDD"，默认为空。
# #         end_date (str, 可选): 结束日期，格式为"YYYYMMDD"，默认为空。
# #         index_component (str, 可选): 指数成分股筛选，默认为None。
# #         symbol_type (str, 可选): 标的类型，可选值为"stock"（股票）、"future"（期货），默认为"stock"。
# #
# #     返回：
# #         Optional[pd.DataFrame]: 满足条件的因子数据，若无数据则返回None。
# #     """
# #     # 初始化数据库处理器
# #     db_handler = DatabaseHandler(config)
# #
# #     all_data = []
# #
# #     # 处理factors参数
# #     if factors is None:
# #         # 如果没有指定factors，返回所有基础因子
# #         factors = ["open", "close", "high", "low", "volume", "market_cap", "turnover", "amount"]
# #     elif isinstance(factors, str):
# #         # Convert factor name to lowercase
# #         factors = [factors.lower()]
# #     elif isinstance(factors, list):
# #         # Convert all factor names to lowercase
# #         factors = [f.lower() for f in factors]
# #
# #     # 检查是否有基础因子
# #     base_factors = ["open", "close", "high", "low", "volume", "market_cap", "turnover", "amount"]
# #     requested_base_factors = [f for f in factors if f in base_factors]
# #
# #     # 如果有基础因子，查一次库，再选择留什么字段
# #     if requested_base_factors:
# #         # 单次查询 factor_base 表
# #         query = {}
# #
# #         # 添加symbols筛选条件
# #         if symbol:
# #             if isinstance(symbol, list):
# #                 # 如果symbols是列表，使用$in操作符
# #                 query["symbol"] = {"$in": symbol}
# #             else:
# #                 # 如果symbols是字符串，直接匹配
# #                 query["symbol"] = symbol
# #
# #         # 添加日期范围条件
# #         if start_date and end_date:
# #             query["date"] = {"$gte": start_date, "$lte": end_date}
# #         elif start_date:
# #             query["date"] = {"$gte": start_date}
# #         elif end_date:
# #             query["date"] = {"$lte": end_date}
# #
# #         # 添加指数成分股筛选条件
# #         if index_component:
# #             query['index_component'] = {"$eq": index_component}
# #
# #         # 构建投影，只查询需要的字段
# #         base_fields = ['date', 'symbol']  # 基础字段
# #         projection = {field: 1 for field in base_fields + requested_base_factors}
# #         projection['_id'] = 0  # 不包含_id字段
# #
# #         if symbol_type == 'future':
# #             # Add $expr condition to match symbol with underlying_symbol + "88"
# #             query["$expr"] = {
# #                 "$eq": [
# #                     "$symbol",
# #                     {"$concat": ["$underlying_symbol", "88"]}
# #                 ]
# #             }
# #             # 获取集合并使用批量优化
# #             collection = db_handler.get_mongo_collection(
# #                 config["MONGO_DB"],
# #                 "future_market_post"
# #             )
# #             cursor = collection.find(query, projection).batch_size(100000)
# #             records = list(cursor)
# #         else:
# #             # 获取集合并使用批量优化
# #             collection = db_handler.get_mongo_collection(
# #                 config["MONGO_DB"],
# #                 "factor_base_post"
# #             )
# #             cursor = collection.find(query, projection).batch_size(100000)
# #             records = list(cursor)
# #
# #         if records:
# #             # Convert to DataFrame
# #             df = pd.DataFrame(records)
# #             all_data.append(df)
# #
# #     if not all_data:
# #         logger.warning(f"No data found for the specified parameters")
# #         return None
# #
# #     # Merge all dataframes on date and symbol
# #     result = all_data[0]
# #     for df in all_data[1:]:
# #         result = pd.merge(
# #             result,
# #             df,
# #             on=['date', 'symbol'],
# #             how='outer'
# #         )
# #     return result
#
#
# def get_custom_factor(factor_name: str,
#                       start_date: str,
#                       end_date: str,
#                       symbol_type: Optional[str] = 'stock') -> Optional[pd.DataFrame]:
#     """
#     获取自定义因子数据
#
#     参数：
#         factor_name (str): 因子名称。
#         start_date (str): 查询起始日期，格式如 '20230101'。
#         end_date (str): 查询结束日期，格式如 '20231231'。
#         symbol_type (Optional[str]): 标的类型，默认为 'stock'。
#
#     返回：
#         Optional[pd.DataFrame]: 查询到的因子数据表，若无数据则返回 None。
#     """
#     panda_data.init()
#     return panda_data.get_custom_factor(factor_logger=logger, user_id=0, factor_name=factor_name, start_date=start_date,
#                                         end_date=end_date, symbol_type=symbol_type)
#
#
# def create_factor_from_class(class_code: str, start_date: str,
#                              end_date: str, symbols: Optional[List[str]] = None,
#                              index_component: Optional[str] = None, symbol_type: Optional[str] = 'stock') -> Optional[pd.DataFrame]:
#     """
#     通过类代码创建因子
#
#     参数：
#         class_code (str): 因子类代码。
#         start_date (str): 查询起始日期，格式如 '20230101'。
#         end_date (str): 查询结束日期，格式如 '20231231'。
#         symbols (Optional[List[str]]): 股票或标的代码列表，默认为 None，表示全部。
#         index_component (Optional[str]): 指数成分，默认为 None。
#         symbol_type (Optional[str]): 标的类型，默认为 'stock'。
#
#     返回：
#         Optional[pd.DataFrame]
#     """
#     macro_factor = MacroFactor()
#     return macro_factor.create_factor_from_class(factor_logger=logger, class_code=class_code, start_date=start_date,
#                                                 end_date=end_date, symbols=symbols, index_component=index_component, symbol_type=symbol_type)
#
#
# def create_factor_from_formula(formula: str, start_date: str,
#                                end_date: str, symbols: Optional[List[str]] = None,
#                                index_component: Optional[str] = None,
#                                symbol_type: Optional[str] = 'stock') -> Optional[pd.DataFrame]:
#     """
#     通过公式创建因子
#
#     参数：
#         formula (str): 因子公式。
#         start_date (str): 查询起始日期，格式如 '20230101'。
#         end_date (str): 查询结束日期，格式如 '20231231'。
#         symbols (Optional[List[str]]): 股票或标的代码列表，默认为 None，表示全部。
#         index_component (Optional[str]): 指数成分，默认为 None。
#         symbol_type (Optional[str]): 标的类型，默认为 'stock'。
#
#     返回：
#         Optional[pd.DataFrame]
#     """
#     macro_factor = MacroFactor()
#     return macro_factor.create_factor_from_formula(factor_logger=logger, formula=formula, start_date=start_date,
#                                                   end_date=end_date, symbols=symbols,
#                                                   index_component=index_component, symbol_type=symbol_type)
#
# def factor_analysis(start_date: str, end_date: str,
#                     name:Optional[str] = "未命名因子",
#                     factor_type: Optional[str] = "stock", is_persistent: Optional[bool] = False,
#                     cron: Optional[str] = "",
#                     code: Optional[str] = "class MomentumFactor(Factor):\n    def calculate(self, factors):\n        close = factors['close']\n        returns = RETURNS(close, period=20)\n        return RANK(returns)",
#                     code_type:Optional[str] = 'python',
#                     status:Optional[int] = 0,adjustment_cycle:Optional[int] = 1,
#                     stock_pool:Optional[str] = "000300",factor_direction:Optional[bool] = True,
#                     group_number:Optional[int] = 5,include_st:Optional[bool] = False,
#                     extreme_value_processing: Optional[str] = "标准差") -> Optional[pd.DataFrame]:
#     """
#     因子分析主函数。
#
#     参数:
#         start_date (str): 分析起始日期
#         end_date (str): 分析结束日期
#         name (str, 可选): 因子名称，默认为"未命名因子"
#         factor_type (str, 可选): 因子类型，默认为"stock"
#         is_persistent (bool, 可选): 是否持久化，默认为False
#         cron (str, 可选): 定时任务表达式，默认为空
#         code (str, 可选): 代码，默认为"stock"
#         code_type (str, 可选): 代码类型，默认为'python'
#         status (int, 可选): 状态，默认为0
#         adjustment_cycle (int, 可选): 调仓周期，默认为1
#         stock_pool (str, 可选): 股票池，默认为"000300"
#         factor_direction (bool, 可选): 因子方向，默认为True
#         group_number (int, 可选): 分组数，默认为5
#         include_st (bool, 可选): 是否包含ST，默认为False
#         extreme_value_processing (str, 可选): 极值处理方式，默认为"标准差"
#     返回:
#         Optional[pd.DataFrame]: 因子分析结果
#     """
#     # 创建因子请求体
#     create_factor_request = CreateFactorRequest(**{
#         "user_id": "0",
#         "name": name,
#         "factor_name": generate_unique_factor_name(),
#         "factor_type": factor_type,
#         "is_persistent": is_persistent,
#         "cron": cron,
#         "factor_start_day": datetime.today().strftime('%Y-%m-%d'),
#         "code": code,
#         "code_type": code_type,
#         "status": status,
#         "describe": "",
#         "tags": "",
#         "params": {
#             "start_date": start_date,
#             "end_date": end_date,
#             "adjustment_cycle": adjustment_cycle,
#             "stock_pool": stock_pool,
#             "factor_direction": factor_direction,
#             "group_number": group_number,
#             "include_st": include_st,
#             "extreme_value_processing": extreme_value_processing
#         }
#     })
#     factor_id = create_factor(factor = create_factor_request).data["factor_id"]
#     # 因子分析执行
#     task_id = run_factor(message_id = factor_id, is_thread=False).data["task_id"]
#     query = {
#         "factor_id": factor_id,
#         "task_id": task_id
#     }
#     db_handler = DatabaseHandler(config)
#     projection = {
#         "_id": 0,
#         "factor_name": 1,
#         "factor_id": 1,
#         "task_id": 1,
#         "factor_data_analysis": 1,
#         "one_group_data": 1
#     }
#     # 获取因子执行结果
#     result = db_handler.mongo_find(config["MONGO_DB"], "factor_analysis_results", query, projection)
#     return result
#
#
# def generate_unique_factor_name():
#     # 前两位随机字母
#     letters = ''.join(secrets.choice(string.ascii_letters) for _ in range(2))
#     # 取UUID的前7位（去掉中划线，取hex字符串）
#     uuid_part = uuid.uuid4().hex[:7]
#     return letters + uuid_part
#
#
#
#
