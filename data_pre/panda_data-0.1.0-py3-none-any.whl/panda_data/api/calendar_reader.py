from typing import Optional, List, Union
import pandas as pd
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_trading_calendar(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    exchange: Optional[str] = "SH",
    is_trading_day: Optional[int] = None,
    fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    获取交易日历数据
    
    Args:
        start_date: 开始日期，格式 "YYYYMMDD"，默认为None
        end_date: 结束日期，格式 "YYYYMMDD"，默认为None
        exchange: 交易所代码，默认为"SH"，可选"SZ"等
        is_trading_day: 是否为交易日，1=交易日，0=非交易日，None=全部
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含交易日历数据的DataFrame，按日期升序排列
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if exchange:
        query['exchange'] = exchange
    if is_trading_day is not None:
        query['is_trade'] = is_trading_day
    if start_date:
        query['nature_date'] = {'$gte': int(start_date)}
    if end_date:
        if 'nature_date' in query:
            query['nature_date']['$lte'] = int(end_date)
        else:
            query['nature_date'] = {'$lte': int(end_date)}
    
    # 构建投影
    projection = None
    if fields:
        # 确保 nature_date 一定在返回字段中
        if "nature_date" not in fields:
            fields.append("nature_date")
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0
    
    # 执行查询
    result = pd.DataFrame(db_handler.find_documents(config["MONGO_DB"], "trade_calendar", query, projection))
    
    # 按日期升序排列
    if not result.empty and "nature_date" in result.columns:
        result = result.sort_values(by="nature_date", ascending=True)
        result = result.reset_index(drop=True)
    
    return result


def get_trading_days(
    start_date: str,
    end_date: str,
    exchange: Optional[str] = "SH",
    fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    获取指定日期范围内的交易日
    
    Args:
        start_date: 开始日期，格式 "YYYYMMDD"
        end_date: 结束日期，格式 "YYYYMMDD"
        exchange: 交易所代码，默认为"SH"
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含交易日数据的DataFrame，按日期升序排列
    """
    return get_trading_calendar(
        start_date=start_date,
        end_date=end_date,
        exchange=exchange,
        is_trading_day=1,
        fields=fields
    )


def get_non_trading_days(
    start_date: str,
    end_date: str,
    exchange: Optional[str] = "SH",
    fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    获取指定日期范围内的非交易日
    
    Args:
        start_date: 开始日期，格式 "YYYYMMDD"
        end_date: 结束日期，格式 "YYYYMMDD"
        exchange: 交易所代码，默认为"SH"
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含非交易日数据的DataFrame，按日期升序排列
    """
    return get_trading_calendar(
        start_date=start_date,
        end_date=end_date,
        exchange=exchange,
        is_trading_day=0,
        fields=fields
    )


def is_trading_day(date: str, exchange: Optional[str] = "SH") -> bool:
    """
    判断指定日期是否为交易日
    
    Args:
        date: 日期，格式 "YYYYMMDD"
        exchange: 交易所代码，默认为"SH"
    
    Returns:
        bool: True表示是交易日，False表示非交易日
    """
    result = get_trading_calendar(
        start_date=date,
        end_date=date,
        exchange=exchange,
        fields=["is_trade"]
    )
    
    if result.empty:
        return False
    
    return bool(result.iloc[0]['is_trade'])


def get_previous_trading_date(
    date: str,
    exchange: Optional[str] = "SH",
    n: int = 1
) -> Optional[str]:
    """
    获取指定日期的前n个交易日
    
    Args:
        date: 基准日期，格式 "YYYYMMDD"
        exchange: 交易所代码，默认为"SH"
        n: 前n个交易日，默认为1
    
    Returns:
        str: 前n个交易日，格式 "YYYYMMDD"，如果没有则返回None
    """
    db_handler = DatabaseHandler(config)
    
    query = {
        'exchange': exchange,
        'is_trade': 1,
        'nature_date': {'$lt': int(date)}
    }
    
    projection = {'nature_date': 1, '_id': 0}
    
    # 查询前n个交易日，按日期降序排列
    result = db_handler.find_documents(
        config["MONGO_DB"], "trade_calendar", query, projection,
        sort=[('nature_date', -1)], limit=n
    )
    
    if len(result) >= n:
        return str(result[n-1]['nature_date'])
    
    return None


def get_next_trading_date(date: str, exchange: Optional[str] = "SH") -> Optional[str]:
    """
    获取指定日期的下一个交易日
    
    Args:
        date: 指定日期，格式为 'YYYYMMDD'
        exchange: 交易所代码，默认为 'SH'
        
    Returns:
        下一个交易日，格式为 'YYYYMMDD'，如果没有找到则返回 None
    """
    db_handler = DatabaseHandler(config)
    
    query = {
        'exchange': exchange,
        'is_trade': 1,
        'nature_date': {'$gt': int(date)}
    }
    
    projection = {'nature_date': 1, '_id': 0}
    
    # 按日期升序排列，获取最近的一个交易日
    result = db_handler.find_documents(
        config["MONGO_DB"], "trade_calendar", query, projection,
        sort=[('nature_date', 1)], limit=1
    )
    
    if result:
        return str(result[0]['nature_date'])
    return None


def get_trading_days_count(
    start_date: str,
    end_date: str,
    exchange: Optional[str] = "SH"
) -> int:
    """
    获取指定日期范围内的交易日数量
    
    Args:
        start_date: 开始日期，格式 "YYYYMMDD"
        end_date: 结束日期，格式 "YYYYMMDD"
        exchange: 交易所代码，默认为"SH"
    
    Returns:
        int: 交易日数量
    """
    db_handler = DatabaseHandler(config)
    
    query = {
        'exchange': exchange,
        'is_trade': 1,
        'nature_date': {
            '$gte': int(start_date),
            '$lte': int(end_date)
        }
    }
    
    # 使用collection.count_documents计算数量
    collection = db_handler.get_mongo_collection(config["MONGO_DB"], "trade_calendar")
    count = collection.count_documents(query)
    return count


def get_latest_trading_date(exchange: Optional[str] = "SH") -> Optional[str]:
    """
    获取最新的交易日
    
    Args:
        exchange: 交易所代码，默认为"SH"
    
    Returns:
        str: 最新交易日，格式 "YYYYMMDD"，如果没有则返回None
    """
    db_handler = DatabaseHandler(config)
    
    query = {
        'exchange': exchange,
        'is_trade': 1
    }
    
    projection = {'nature_date': 1, '_id': 0}
    
    # 查询最新的交易日，按日期降序排列
    result = db_handler.find_documents(
        config["MONGO_DB"], "trade_calendar", query, projection,
        sort=[('nature_date', -1)], limit=1
    )
    
    if result:
        return str(result[0]['nature_date'])
    
    return None


def get_trading_days_list(
    start_date: str,
    end_date: str,
    exchange: Optional[str] = "SH",
    limit: Optional[int] = None
) -> List[str]:
    """
    获取指定日期范围内的交易日列表
    
    Args:
        start_date: 开始日期，格式为 'YYYYMMDD'
        end_date: 结束日期，格式为 'YYYYMMDD'
        exchange: 交易所代码，默认为 'SH'
        limit: 限制返回数量，可选
        
    Returns:
        交易日列表，格式为 ['YYYYMMDD', ...]
    """
    db_handler = DatabaseHandler(config)
    
    query = {
        'exchange': exchange,
        'is_trade': 1,
        'nature_date': {
            '$gte': int(start_date),
            '$lte': int(end_date)
        }
    }
    
    projection = {'nature_date': 1, '_id': 0}
    
    # 按日期升序排列
    result = db_handler.find_documents(
        config["MONGO_DB"], "trade_calendar", query, projection,
        sort=[('nature_date', 1)], limit=limit
    )
    
    return [str(doc['nature_date']) for doc in result]