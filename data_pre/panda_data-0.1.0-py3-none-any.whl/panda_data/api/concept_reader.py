import pandas as pd
from typing import Optional, Union, List
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_concept_list(
        concept: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取概念列表

    Args:
        concept: 概念名称，如 "林权流转" 或 ["林权流转", "医疗废物处理"]，默认为None返回所有
        start_date：开始时间,格式："YYYYMMDD"
        end_date: 结束时间，格式："YYYYMMDD"
        fields: 需要返回的字段列表，默认为None返回全部字段
    return：
        DataFrame：包含概念股名称的DataFrame
    """
    db_handler = DatabaseHandler(config)
    query = {}
    if concept:
        if isinstance(concept, list):
            query["name"] = {"$in": concept}
        else:
            query["name"] = concept
    if start_date and end_date:
        query["date"] = {"$gte": start_date, "$lte": end_date}
    elif start_date:
        query["date"] = {"$gte": start_date}
    elif end_date:
        query["date"] = {"$lte": end_date}
    if fields is None:
        projection = {"_id": 0}
    else:
        if "name" not in fields:
            fields.append("name")
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "concept_list", query, projection))

    # 排序：先按symbol升序，再按date降序
    if not result.empty and "name" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["name", "date"], ascending=[True, False])
        result = result.reset_index(drop=True)

    return result


def get_concept_stock(
        concept: Optional[Union[str, List[str]]] = None,
        concept_stock: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取概念成分股信息

    Args:
        concept: 概念名称，如 "医疗废物处理" 或 ["医疗废物处理", "林权流转"]，默认为None返回所有
        concept_stock: 股票代码，如"300929.SZ"
        start_date: 开始时间，格式"YYYYMMDD"
        end_date: 结束时间，格式"YYYYMMDD"
        fields: 需要返回的字段列表，默认为None返回全部字段
    Returns:
        DataFrame: 查询结果
    """
    db_handler = DatabaseHandler(config)
    query = {}
    if concept:
        if isinstance(concept, list):
            query["concept"] = {"$in": concept}
        else:
            query["concept"] = concept
    if concept_stock:
        query["concept_stock"] = concept_stock
    if start_date and end_date:
        query["date"] = {"$gte": start_date, "$lte": end_date}
    elif start_date:
        query["date"] = {"$gte": start_date}
    elif end_date:
        query["date"] = {"$lte": end_date}
    if fields is None:
        projection = {"_id": 0}
    else:
        if "concept" not in fields:
            fields.append("concept")
        if "concept_stock" not in fields:
            fields.append("concept_stock")
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "concept_stock", query, projection))

    # 排序：先按concept_stock升序，再按date降序
    if not result.empty and "concept_stock" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["concept_stock","date"], ascending=[True, False])
        result = result.reset_index(drop=True)

    return pd.DataFrame(result)
    