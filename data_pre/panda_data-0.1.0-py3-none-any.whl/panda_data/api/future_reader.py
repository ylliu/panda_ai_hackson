from typing import Optional
import pandas as pd
import re

from ..common.handlers.parquet_handler import ParquetHandler
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import get_config


def get_future_list() -> pd.DataFrame:
    """
        获取期货列表

        参数:
            无

        返回:
            str: 带交易所后缀的指数代码(如"000001.SH")或"UNKNOWN"
        """
    config = get_config()
    query = {}
    db_handler = DatabaseHandler(config)
    projection = {
        "_id": 0,
        "symbol": 1
    }
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "future_symbol", query, projection))

    # 过滤掉不符合要求的symbol
    if not result.empty and "symbol" in result.columns:
        # 定义需要过滤的模式
        exclude_patterns = [
            r'^[A-Za-z]+88$',
            r'^[A-Za-z]+888$',
            r'^[A-Za-z]+889$',
            r'^[A-Za-z]+88[A-Za-z]\d$',
            r'^[A-Za-z]+99$',
            r'.*_.*'
        ]
        
        # 编译正则表达式
        compiled_patterns = [re.compile(pattern) for pattern in exclude_patterns]
        
        # 过滤掉匹配任何模式的symbol
        def should_exclude(symbol):
            if pd.isna(symbol):
                return True
            symbol_str = str(symbol)
            return any(pattern.match(symbol_str) for pattern in compiled_patterns)
        
        result = result[~result['symbol'].apply(should_exclude)]
        
        # 排序：先按symbol升序
        result = result.sort_values(by="symbol", ascending=True)
        result = result.reset_index(drop=True)
    return result


def get_future_factor_post(symbol: Optional[str] = None,
                           start_date: Optional[str] = None,
                           end_date: Optional[str] = None,
                           fields: Optional[list] = None) -> pd.DataFrame:
    """
       获取期货后复权行情数据。

       参数：
           symbol (str, 可选): 产品代码，如股票、期货、指数代码，默认为空，返回所有。
           start_date (str, 可选): 起始日期，格式为"YYYYMMDD"，默认为空。
           end_date (str, 可选): 结束日期，格式为"YYYYMMDD"，默认为空。
           fields (list, 可选): 需要返回的字段列表，默认为None返回全部字段。

       返回：
           pd.DataFrame: 满足条件的期货行情数据，按日期降序排列。
       """
    config = get_config()
    
    # 检查配置是否存在
    if not config or "future_market_post_parquet_path" not in config:
        raise ValueError("配置文件中缺少 'future_market_post_parquet_path' 配置项")
    
    parquet_path = config["future_market_post_parquet_path"]
    print("*******"+parquet_path+"*******")
    
    factor_base_reader = ParquetHandler(parquet_path)
    
    # 构建查询的列列表
    if fields is None:
        # 如果fields为None，返回所有字段（不包含_id）
        columns_to_query = [
            "date", "symbol", "amount", "close", "day_session_open", "dominant_id",
            "exchange", "high", "limit_down", "limit_up", "low", "open", 
            "open_interest", "pre_settlement", "settlement", "trading_code", 
            "underlying_symbol", "volume"
        ]
    else:
        # 如果指定了fields，确保包含基础字段
        base_fields = ["symbol", "date"]
        columns_to_query = base_fields + [field for field in fields if field not in base_fields]

    result = factor_base_reader.query_data(
        start_date=start_date,
        end_date=end_date,
        columns=columns_to_query,
        symbols=symbol,
        custom_conditions=None
    )
    # 排序：先按symbol升序，再按date降序
    if not result.empty and "symbol" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["symbol","date"], ascending=[True,False])
        result = result.reset_index(drop=True)

    return result

