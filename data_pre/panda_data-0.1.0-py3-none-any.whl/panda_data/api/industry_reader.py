from typing import Optional, List
import pandas as pd
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_industry_stock(industry_code: Optional[str] = None, 
                      stock_symbol: Optional[str] = None,
                      level: Optional[str] = None,
                      fields: Optional[List[str]] = None,
                      limit: Optional[int] = None) -> pd.DataFrame:

    """
    获取行业股票成分数据
    
    Args:
        industry_code: 行业代码，如 "801010" (注意：无.SI后缀)
        stock_symbol: 股票代码，如 "000001.SZ"
        level: 行业级别，如 "L1", "L2", "L3"
        fields: 需要返回的字段列表
        limit: 返回记录数限制，用于分页查询
    
    Returns:
        DataFrame: 包含行业股票成分信息的DataFrame
        
    Note:
        - 支持多行业-股票关系，一只股票可能属于多个行业
    """

    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if industry_code:
        # 支持按不同级别的行业代码查询
        if level == "L1" or not level:
            query['l1_code'] = industry_code
        elif level == "L2":
            query['l2_code'] = industry_code
        elif level == "L3":
            query['l3_code'] = industry_code
        else:
            # 兼容旧格式，自动匹配
            query['$or'] = [
                {'l1_code': industry_code},
                {'l2_code': industry_code},
                {'l3_code': industry_code}
            ]
    if stock_symbol:
        query['stock_symbol'] = stock_symbol
    if level and not industry_code:
        # 仅按级别筛选时，确保该级别字段存在且非空
        if level == "L1":
            query['l1_code'] = {'$exists': True, '$ne': None, '$ne': ''}
        elif level == "L2":
            query['l2_code'] = {'$exists': True, '$ne': None, '$ne': ''}
        elif level == "L3":
            query['l3_code'] = {'$exists': True, '$ne': None, '$ne': ''}
    
    # 构建投影字段
    projection = {'_id': 0}  # 默认不返回_id字段
    if fields:
        # 确保stock_symbol字段总是包含在结果中
        if 'stock_symbol' not in fields:
            fields.append('stock_symbol')
        for field in fields:
            projection[field] = 1
    
    # 构建查询选项
    query_options = {}
    if limit:
        query_options['limit'] = limit
    
    # 执行查询
    if limit:
        # 使用支持limit的find_documents方法
        result = db_handler.find_documents(
            db_name=config["MONGO_DB"],
            collection_name="industry_stock",
            filter_dict=query,
            projection=projection,
            limit=limit,
            sort=[("stock_symbol", 1)]
        )
    else:
        # 使用原有的mongo_find方法
        result = db_handler.mongo_find(config["MONGO_DB"], "industry_stock", query, projection)
    
    if not result:
        return pd.DataFrame()
    
    # 转换为DataFrame
    df = pd.DataFrame(result)
    
    # 为了保持向后兼容性，添加industry_code列（默认使用L1级别）
    if not df.empty and 'industry_code' not in df.columns:
        if level == "L2" and 'l2_code' in df.columns:
            df['industry_code'] = df['l2_code']
        elif level == "L3" and 'l3_code' in df.columns:
            df['industry_code'] = df['l3_code']
        else:
            # 默认使用L1级别
            if 'l1_code' in df.columns:
                df['industry_code'] = df['l1_code']
    
    # 排序：按stock_symbol升序，便于查看（仅在未使用limit时需要）
    if not limit and not df.empty and 'stock_symbol' in df.columns:
        df = df.sort_values(by="stock_symbol", ascending=True)
        # 重置索引
        df = df.reset_index(drop=True)
    
    return df


def get_industry_list(level: Optional[str] = "L1", 
                     fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取行业列表
    
    Args:
        level: 行业级别，如 "L1", "L2", "L3"，默认为"L1"
        fields: 需要返回的字段列表
    
    Returns:
        DataFrame: 行业列表信息
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件 - 获取去重的行业信息
    pipeline = []
    
    # 根据级别选择对应的字段进行分组
    if level == "L1":
        group_fields = {
            '_id': '$l1_code',
            'industry_code': {'$first': '$l1_code'},
            'industry_name': {'$first': '$l1_name'}
        }
    elif level == "L2":
        group_fields = {
            '_id': '$l2_code',
            'industry_code': {'$first': '$l2_code'},
            'industry_name': {'$first': '$l2_name'},
            'parent_code': {'$first': '$l1_code'},
            'parent_name': {'$first': '$l1_name'}
        }
    elif level == "L3":
        group_fields = {
            '_id': '$l3_code',
            'industry_code': {'$first': '$l3_code'},
            'industry_name': {'$first': '$l3_name'},
            'parent_l2_code': {'$first': '$l2_code'},
            'parent_l2_name': {'$first': '$l2_name'},
            'parent_l1_code': {'$first': '$l1_code'},
            'parent_l1_name': {'$first': '$l1_name'}
        }
    else:
        # 默认返回L1级别
        group_fields = {
            '_id': '$l1_code',
            'industry_code': {'$first': '$l1_code'},
            'industry_name': {'$first': '$l1_name'}
        }
    
    # 过滤空值
    match_condition = {f"{level.lower()}_code": {'$exists': True, '$ne': None, '$ne': ''}}
    pipeline.append({'$match': match_condition})
    
    # 分组去重
    pipeline.append({'$group': group_fields})
    
    # 排序
    pipeline.append({'$sort': {'industry_code': 1}})
    
    # 重新投影，移除_id字段
    projection_stage = {'$project': {'_id': 0}}
    if fields:
        # 如果指定了字段，只返回指定字段
        for field in fields:
            projection_stage['$project'][field] = 1
    pipeline.append(projection_stage)
    
    # 执行聚合查询
    collection = db_handler.mongo_client[config["MONGO_DB"]]['industry_stock']
    result = list(collection.aggregate(pipeline))
    
    if not result:
        return pd.DataFrame()
    
    # 转换为DataFrame
    df = pd.DataFrame(result)
    # 排序：按industry_code升序
    if not df.empty and 'industry_code' in df.columns:
        df = df.sort_values(by="industry_code", ascending=True)
        # 重置索引
        df = df.reset_index(drop=True)
    
    return df


def get_stock_industry(stock_symbol: str, 
                      level: Optional[str] = "L1") -> pd.DataFrame:
    """
    获取指定股票所属的行业信息
    
    Args:
        stock_symbol: 股票代码，如 "000001.SZ"
        level: 返回的行业级别，如 "L1", "L2", "L3"，默认为"L1"
    
    Returns:
        DataFrame: 股票所属行业信息
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {'stock_symbol': stock_symbol}
    
    # 根据级别选择返回字段
    if level == "L1":
        projection = {
            '_id': 0,
            'stock_symbol': 1,
            'industry_code': '$l1_code',
            'industry_name': '$l1_name'
        }
    elif level == "L2":
        projection = {
            '_id': 0,
            'stock_symbol': 1,
            'industry_code': '$l2_code',
            'industry_name': '$l2_name',
            'parent_code': '$l1_code',
            'parent_name': '$l1_name'
        }
    elif level == "L3":
        projection = {
            '_id': 0,
            'stock_symbol': 1,
            'industry_code': '$l3_code',
            'industry_name': '$l3_name',
            'parent_l2_code': '$l2_code',
            'parent_l2_name': '$l2_name',
            'parent_l1_code': '$l1_code',
            'parent_l1_name': '$l1_name'
        }
    else:
        # 默认返回L1级别
        projection = {
            '_id': 0,
            'stock_symbol': 1,
            'industry_code': '$l1_code',
            'industry_name': '$l1_name'
        }
    
    # 使用聚合管道进行查询和投影
    collection = db_handler.mongo_client[config["MONGO_DB"]]['industry_stock']
    pipeline = [
        {'$match': query},
        {'$project': projection}
    ]
    
    result = list(collection.aggregate(pipeline))
    
    if not result:
        return pd.DataFrame()
    
    # 转换为DataFrame
    df = pd.DataFrame(result)
    
    return df