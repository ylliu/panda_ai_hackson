import pandas as pd
from typing import Optional, Union, List
from panda_data.common.handlers.database_handler import DatabaseHandler
from panda_data.common.handlers.parquet_handler import ParquetHandler
from panda_data.common.config import config, get_config


def get_stock_market_data(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: str = "",
    end_date: str = "",
    time_type: str = "1d",
    fields: Optional[List[str]] = None,
    data_source: str = "parquet"
) -> pd.DataFrame:
    """
    获取股票行情数据（用于策略回测）
    
    参数:
        symbol (str 或 List[str], 可选): 股票代码，可以是单个代码字符串或代码列表，如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，默认为None返回所有
        start_date (str): 起始日期，格式为"YYYYMMDD"，如 "20250101"，必填
        end_date (str): 结束日期，格式为"YYYYMMDD"，如 "20250131"，必填
        time_type (str): 时间类型，可选值为 "1d"（日线）或 "1m"（分钟线），默认为 "1d"
        fields (List[str], 可选): 需要返回的字段列表，默认为None返回全部字段
        data_source (str): 数据源，可选值为 "mongodb" 或 "parquet"，默认为 "parquet"
    
    返回:
        pd.DataFrame: 满足条件的股票行情数据，按symbol升序、date降序排列
    
    异常:
        ValueError: 当参数格式无效或数据源不支持时
    """
    # 验证必填参数
    if not start_date or not end_date:
        raise ValueError("start_date 和 end_date 不能为空")
    
    # 验证时间类型参数
    if time_type not in ["1d", "1m", "1天", "1分钟"]:
        raise ValueError(f"time_type 参数错误，应为 '1d'、'1m'、'1天' 或 '1分钟'，当前值: {time_type}")
    
    # 标准化时间类型
    if time_type in ["1天", "1d"]:
        time_type = "1d"
    elif time_type in ["1分钟", "1m"]:
        time_type = "1m"
    
    # 验证数据源参数
    if data_source not in ["mongodb", "parquet"]:
        raise ValueError(f"data_source 参数错误，应为 'mongodb' 或 'parquet'，当前值: {data_source}")
    
    # 根据数据源选择不同的读取方式
    if data_source == "mongodb":
        return _get_stock_market_from_mongodb(symbol, start_date, end_date, time_type, fields)
    else:  # parquet
        return _get_stock_market_from_parquet(symbol, start_date, end_date, time_type, fields)


def _get_stock_market_from_mongodb(
    symbol: Optional[Union[str, List[str]]],
    start_date: str,
    end_date: str,
    time_type: str,
    fields: Optional[List[str]]
) -> pd.DataFrame:
    """从MongoDB读取股票行情数据"""
    # 构建查询条件
    query = {}
    
    if symbol:
        if isinstance(symbol, list):
            query["symbol"] = {"$in": symbol}
        else:
            query["symbol"] = symbol
    
    # 根据时间类型选择collection和处理日期范围
    if time_type == "1d":
        collection_name = "stock_market"
        # 日线数据使用字符串日期格式
        date_query = {}
        if start_date:
            date_query["$gte"] = start_date
        if end_date:
            date_query["$lte"] = end_date
        if date_query:
            query["date"] = date_query
    else:  # 1m
        from datetime import datetime, timedelta
        collection_name = "stock_1m_market"
        # 分钟线数据使用datetime类型
        start_dt = datetime.strptime(start_date, "%Y%m%d")
        end_dt = datetime.strptime(end_date, "%Y%m%d")
        end_dt = end_dt + timedelta(days=1) - timedelta(seconds=1)
        query["date"] = {"$gte": start_dt, "$lte": end_dt}
    
    # 处理字段投影
    db_handler = DatabaseHandler(config)
    projection = None
    if fields:
        # 确保 symbol 和 date 一定在返回字段中
        for must_field in ["symbol", "date"]:
            if must_field not in fields:
                fields.append(must_field)
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    else:
        projection = {"_id": 0}
    
    # 执行查询
    result = db_handler.mongo_find(config["MONGO_DB"], collection_name, query, projection)
    df = pd.DataFrame(result)
    
    # 排序：先按symbol升序，再按date降序
    if not df.empty and "date" in df.columns:
        df = df.sort_values(by=["symbol", "date"], ascending=[True, False])
        df = df.reset_index(drop=True)
    
    return df


def _get_stock_market_from_parquet(
    symbol: Optional[Union[str, List[str]]],
    start_date: str,
    end_date: str,
    time_type: str,
    fields: Optional[List[str]]
) -> pd.DataFrame:
    """从Parquet文件读取股票行情数据"""
    config_obj = get_config()
    
    # 根据时间类型选择parquet路径配置
    if time_type == "1d":
        parquet_path_key = "stock_market_parquet_path"
    else:  # 1m
        parquet_path_key = "stock_1m_market_parquet_path"
    
    # 获取parquet路径，如果配置中没有则使用默认路径
    parquet_path = config_obj.get(parquet_path_key)
    if not parquet_path:
        # 如果配置中没有，尝试从环境变量获取
        import os
        parquet_path = os.getenv(parquet_path_key, f"/nas/stock_market_{time_type}")
    
    if not parquet_path:
        raise ValueError(f"配置文件中缺少 '{parquet_path_key}' 配置项，且环境变量中也没有设置")
    
    # 创建ParquetHandler
    parquet_reader = ParquetHandler(parquet_path)
    
    # 处理symbol参数，转换为列表格式
    symbols_list = None
    if symbol:
        if isinstance(symbol, str):
            symbols_list = [symbol]
        else:
            symbols_list = symbol
    
    # 处理字段列表
    columns_to_query = None
    if fields:
        # 确保包含基础字段
        base_fields = ["symbol", "date"]
        columns_to_query = base_fields + [field for field in fields if field not in base_fields]
    
    # 查询数据
    result = parquet_reader.query_data(
        start_date=start_date,
        end_date=end_date,
        columns=columns_to_query,
        symbols=symbols_list,
        custom_conditions=None
    )
    
    # 排序：先按symbol升序，再按date降序
    if not result.empty and "symbol" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["symbol", "date"], ascending=[True, False])
        result = result.reset_index(drop=True)
    
    return result


