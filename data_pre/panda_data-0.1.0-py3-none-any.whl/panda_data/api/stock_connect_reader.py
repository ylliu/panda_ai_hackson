import pandas as pd
from typing import Optional, Union, List
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config

def get_stock_connect(symbol: Optional[Union[str, List[str]]] = None,
                      start_date: Optional[str] = None,
                      end_date: Optional[str] = None,
                      fields: Optional[List[str]] = None
                      ) -> pd.DataFrame:
    """
    获取沪深股通持股信息
    
    Args:
        symbol: 沪深股通股票代码，如 "000001.SZ" 或 ["000001.SZ", "688981.SH"]，默认为None返回所有
        start_date: 开始时间，格式 "YYYYMMDD"
        end_date: 结束时间，格式 "YYYYMMDD"
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 查询结果
    """
    # 构建查询条件
    query = {}
    if symbol:
        if isinstance(symbol, list):
            query["symbol"] = {"$in": symbol}
        else:
            query["symbol"] = symbol
    if start_date and end_date:
        query['date'] = {'$gte': start_date, '$lte': end_date}
    elif start_date:
        query['date'] = {'$gte': start_date}
    elif end_date:
        query['date'] = {'$lte': end_date}

    db_handler = DatabaseHandler(config)

    projection = None
    if fields:
        # 确保一定在返回字段中
        for must_field in ["symbol","date"]:
            if must_field not in fields:
                fields.append(must_field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0

    # 执行查询
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "stock_connect_info", query, projection))

    # 排序：先按symbol升序，再按date降序
    if not result.empty and "symbol" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["symbol","date"], ascending=[True,False])
        result = result.reset_index(drop=True)

    return result

