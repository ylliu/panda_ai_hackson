from typing import Optional, Union, List
import pandas as pd
import os

from panda_data.common.handlers.parquet_handler import ParquetHandler
from panda_data.common.config import config
from panda_data.common.parquet_path import *

def get_stock_factor_base(
    symbol: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    fields: Optional[List[str]] = None,
    data_source: str = "mongodb",
    market: str = "cn"
) -> pd.DataFrame:
    """
    获取股票基础因子数据（后复权）
    
    参数:
        symbol (str 或 List[str], 可选): 股票代码，可以是单个代码字符串或代码列表，
                                        如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，
                                        默认为None返回所有股票
        start_date (str, 可选): 起始日期，格式为"YYYYMMDD"，如 "20250101"，默认为None
        end_date (str, 可选): 结束日期，格式为"YYYYMMDD"，如 "20250131"，默认为None
        fields (List[str], 可选): 需要返回的字段列表，如 ["open", "close", "high", "low", "volume"]，
                                 默认为None返回全部字段
                                 常用字段包括: open, close, high, low, volume, market_cap, turnover, amount
        data_source (str): 数据源，可选值为 "mongodb" 或 "parquet"，默认为 "mongodb"
        market (str): 市场类型，可选值为 "cn"（A股）、"hk"（港股）、"us"（美股），默认为 "cn"
    
    返回:
        pd.DataFrame: 满足条件的股票基础因子数据，按symbol升序、date降序排列
    
    异常:
        ValueError: 当参数格式无效、数据源不支持或配置文件中缺少必要的配置项时
    """
    # 验证数据源参数
    if data_source not in ["mongodb", "parquet"]:
        raise ValueError(f"data_source 参数错误，应为 'mongodb' 或 'parquet'，当前值: {data_source}")
    
    # 验证市场参数
    if market not in ["cn", "hk", "us"]:
        raise ValueError(f"market 参数错误，应为 'cn'、'hk' 或 'us'，当前值: {market}")
    
    # 根据数据源选择不同的读取方式
    if data_source == "mongodb":
        # TODO: 实现从MongoDB读取的逻辑
        raise NotImplementedError("从MongoDB读取股票基础因子数据的功能尚未实现")
    else:  # parquet
        return _get_stock_factor_base_from_parquet(symbol, start_date, end_date, fields, market)


def _get_stock_factor_base_from_parquet(
    symbol: Optional[Union[str, List[str]]],
    start_date: Optional[str],
    end_date: Optional[str],
    fields: Optional[List[str]],
    market: str
) -> pd.DataFrame:
    """从Parquet文件读取股票基础因子数据"""

    # 根据市场类型选择parquet路径
    if market == "cn":
        # A股
        parquet_path = FACTOR_BASE_POST
    elif market == "hk":
        # 港股
        parquet_path = FACTOR_BASE_POST_HK
    elif market == "us":
        # 美股
        parquet_path = FACTOR_BASE_POST_US
    else:
        raise ValueError(f"不支持的市场类型: {market}")
    
    if not parquet_path:
        raise ValueError(f"配置文件中缺少必要的配置项，无法确定 {market} 市场的parquet路径")
    
    # 创建ParquetHandler
    factor_base_reader = ParquetHandler(parquet_path)
    
    # 处理symbol参数，转换为列表格式
    symbols_list = None
    if symbol:
        if isinstance(symbol, str):
            symbols_list = [symbol]
        else:
            symbols_list = symbol
    
    # 处理字段列表
    columns_to_query = None
    if fields:
        # 确保包含基础字段
        base_fields = ["symbol", "date"]
        columns_to_query = base_fields + [field for field in fields if field not in base_fields]
    
    # 查询数据
    result = factor_base_reader.query_data(
        start_date=start_date,
        end_date=end_date,
        columns=columns_to_query,
        symbols=symbols_list,
        custom_conditions=None
    )
    
    # 排序：先按symbol升序，再按date降序
    if not result.empty and "symbol" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["symbol", "date"], ascending=[True, False])
        result = result.reset_index(drop=True)
    
    return result

