from typing import Optional, Union, List
import pandas as pd

from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_all_funds(
        symbol: Optional[str] = None,
        fields: Optional[list] = None) -> pd.DataFrame:
    """
        获取基金列表

        参数:
            无

        返回:
            str: 带交易所后缀的指数代码(如"000001.SH")或"UNKNOWN"
        """
    query = {}
    if symbol:
        query["symbol"] = symbol
    db_handler = DatabaseHandler(config)

    if fields:
        if "symbol" not in fields:
            fields.append("symbol")
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    else:
        # 如果fields为None，不设置projection（返回所有字段），但排除_id
        projection = {"_id": 0}

    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "fund_basic", query,projection))
    # 排序：按symbol升序
    if not result.empty and "symbol" in result.columns :
        result = result.sort_values(by=["symbol"], ascending=[True])
        result = result.reset_index(drop=True)

    return result


def get_fund_pro(symbol: Optional[str] = None,
                 start_date :Optional[str] = None,
                 end_date:Optional[str] = None,
                 fields: Optional[list] = None) -> pd.DataFrame:
    """
        获取基金持仓数据

        参数:
            无

        返回:
            str: 带交易所后缀的指数代码(如"000001.SH")或"UNKNOWN"
        """
    query = {}
    if symbol:
        query["symbol"] = symbol
    if start_date:
        query["ann_date"] = {"$gte": start_date}
    if end_date:
        if "ann_date" in query:
            query["ann_date"]["$lte"] = end_date
        else:
            query["ann_date"] = {"$lte": end_date}

    db_handler = DatabaseHandler(config)

    if fields:
        if "symbol" not in fields:
            fields.append("symbol")
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    else:
        # 如果fields为None，不设置projection（返回所有字段），但排除_id
        projection = {"_id": 0}
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "fund_portfolio", query,projection))

    # 排序：先按symbol升序，再按date降序
    if not result.empty and "symbol" in result.columns and "ann_date" in result.columns:
        result = result.sort_values(by=["symbol","ann_date"], ascending=[True,False])
        result = result.reset_index(drop=True)
    return result


def get_fund_nav(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[list] = None) -> pd.DataFrame:
    """
        获取基金净值数据

        参数:
            symbol: 基金代码，可以是单个代码(如"024210.OF")或代码列表(如["024210.OF", "000001.OF"])
            start_date: 开始日期(如"20250801")
            end_date: 结束日期(如"20250802")
            fields: 需要返回的字段列表

        返回:
            pd.DataFrame: 基金净值数据
        """
    query = {}
    if symbol:
        if isinstance(symbol, list):
            query["symbol"] = {"$in": symbol}
        else:
            query["symbol"] = symbol
    if start_date:
        query["nav_date"] = {"$gte": start_date}
    if end_date:
        if "nav_date" in query:
            query["nav_date"]["$lte"] = end_date
        else:
            query["nav_date"] = {"$lte": end_date}

    db_handler = DatabaseHandler(config)

    if fields:
        if "symbol" not in fields:
            fields.append("symbol")
        projection = {field: 1 for field in fields}
        projection["_id"] = 0
    else:
        # 如果fields为None，不设置projection（返回所有字段），但排除_id
        projection = {"_id": 0}
    
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "fund_nav", query, projection))

    # 排序：先按symbol升序，再按nav_date降序
    if not result.empty and "symbol" in result.columns and "nav_date" in result.columns:
        result = result.sort_values(by=["symbol", "nav_date"], ascending=[True, False])
        result = result.reset_index(drop=True)
    
    return result