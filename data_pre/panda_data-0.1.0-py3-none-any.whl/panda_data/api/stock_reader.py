import pandas as pd
from typing import Optional, Union,List
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_stock_flow(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    获取股票资金流入流出

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段

    返回:
        包含查询结果的字典列表，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）
    if symbol is not None:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        projection = {field: 1 for field in fields}
        projection['_id'] = 0  # 默认不返回 _id
        # 确保包含 symbol 和 date
        projection.setdefault('symbol', 1)
        projection.setdefault('date', 1)
    result = db_handler.mongo_find(config["MONGO_DB"], "stock_flow_market", query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_audit_opinion(
        symbol: Optional[Union[str, List[str]]] = None,
        start_quarter: Optional[str] = None,
        end_quarter: Optional[str] = None,
        market: Optional[str] = 'cn',
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    从 stock_audit 集合中读取数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_quarter: 开始季度字符串，格式如 "2025q3"（可选）
        end_quarter: 结束季度字符串，格式如 "2025q3"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段
        market: 所查询的市场，'cn' 或其他值（如 'en'），为None时默认查询 'cn' 市场

    返回:
        包含查询结果的 DataFrame，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）- 修复空值处理逻辑
    if symbol is not None:
        # 处理列表情况
        if isinstance(symbol, list):
            # 过滤掉空字符串和None值
            filtered_symbols = [s for s in symbol if s is not None and s != '']
            if filtered_symbols:  # 只有当有过滤后的有效值时才添加查询条件
                query['symbol'] = {'$in': filtered_symbols}
            # 如果过滤后没有有效值，则不添加symbol查询条件，等同于查询所有symbol
        else:
            # 处理单个值情况
            if symbol != '':  # 空字符串不添加查询条件
                query['symbol'] = symbol
            # 空字符串则不添加symbol查询条件，等同于查询所有symbol

    # 处理季度范围参数
    quarter_query = {}
    if start_quarter is not None and start_quarter != '':
        try:
            # 验证季度格式
            if not isinstance(start_quarter, str) or 'q' not in start_quarter.lower():
                raise ValueError("start_quarter 格式无效，应为 'YYYYqN' 格式")
            year, quarter = start_quarter.lower().split('q')
            int(year)
            int(quarter)
            quarter_query['$gte'] = start_quarter
        except (ValueError, IndexError):
            raise ValueError("start_quarter 格式无效，应为 'YYYYqN' 格式")

    if end_quarter is not None and end_quarter != '':
        try:
            # 验证季度格式
            if not isinstance(end_quarter, str) or 'q' not in end_quarter.lower():
                raise ValueError("end_quarter 格式无效，应为 'YYYYqN' 格式")
            year, quarter = end_quarter.lower().split('q')
            int(year)
            int(quarter)
            quarter_query['$lte'] = end_quarter
        except (ValueError, IndexError):
            raise ValueError("end_quarter 格式无效，应为 'YYYYqN' 格式")

    # 如果有季度条件，添加到查询中
    if quarter_query:
        query['quarter'] = quarter_query

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        # 过滤掉空字符串和None值
        filtered_fields = [f for f in fields if f is not None and f != '']
        if filtered_fields:
            projection = {field: 1 for field in filtered_fields}
            projection['_id'] = 0  # 默认不返回 _id
            # 确保包含 symbol 和 date
            projection.setdefault('symbol', 1)
            projection.setdefault('date', 1)

    # 处理 market 参数，确定查询的集合名称
    if market == 'cn':
        collection_name = 'stock_audit'
    else:
        collection_name = f'stock_audit_{market}'
    # 检查集合是否存在
    db = db_handler.mongo_client[config["MONGO_DB"]]
    existing_collections = db.list_collection_names()
    if collection_name not in existing_collections:
        raise ValueError(f"传入的market参数：'{market}'不合法或暂不支持，请尝试当前支持的市场如'cn'")

    result = db_handler.mongo_find(config["MONGO_DB"], collection_name, query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_investor_activities(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    从 stock_investor_relation 集合中读取数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段

    返回:
        包含查询结果的字典列表，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）- 修复空值处理逻辑
    if symbol is not None:
        # 处理列表情况
        if isinstance(symbol, list):
            # 过滤掉空字符串和None值
            filtered_symbols = [s for s in symbol if s is not None and s != '']
            if filtered_symbols:  # 只有当有过滤后的有效值时才添加查询条件
                query['symbol'] = {'$in': filtered_symbols}
            # 如果过滤后没有有效值，则不添加symbol查询条件，等同于查询所有symbol
        else:
            # 处理单个值情况
            if symbol != '':  # 空字符串不添加查询条件
                query['symbol'] = symbol
            # 空字符串则不添加symbol查询条件，等同于查询所有symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None and start_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None and end_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        # 过滤掉空字符串和None值
        filtered_fields = [f for f in fields if f is not None and f != '']
        if filtered_fields:
            projection = {field: 1 for field in filtered_fields}
            projection['_id'] = 0  # 默认不返回 _id
            # 确保包含 symbol 和 date
            projection.setdefault('symbol', 1)
            projection.setdefault('date', 1)

    result = db_handler.mongo_find(config["MONGO_DB"], "stock_investor_relation", query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_restricted_details(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        market: Optional[str] = 'cn',
        fields: Optional[List[str]] = None

) -> pd.DataFrame:
    """
    从 stock_restricted_shares 集合中读取数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段
        market: 所查询的市场，'cn' 或其他值（如 'en'），为None时默认查询 'cn' 市场

    返回:
        包含查询结果的字典列表，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）- 修复空值处理逻辑
    if symbol is not None:
        # 处理列表情况
        if isinstance(symbol, list):
            # 过滤掉空字符串和None值
            filtered_symbols = [s for s in symbol if s is not None and s != '']
            if filtered_symbols:  # 只有当有过滤后的有效值时才添加查询条件
                query['symbol'] = {'$in': filtered_symbols}
            # 如果过滤后没有有效值，则不添加symbol查询条件，等同于查询所有symbol
        else:
            # 处理单个值情况
            if symbol != '':  # 空字符串不添加查询条件
                query['symbol'] = symbol
            # 空字符串则不添加symbol查询条件，等同于查询所有symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None and start_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None and end_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        # 过滤掉空字符串和None值
        filtered_fields = [f for f in fields if f is not None and f != '']
        if filtered_fields:
            projection = {field: 1 for field in filtered_fields}
            projection['_id'] = 0  # 默认不返回 _id
            # 确保包含 symbol 和 date
            projection.setdefault('symbol', 1)
            projection.setdefault('date', 1)

    # 处理 market 参数，确定查询的集合名称
    if market == 'cn':
        collection_name = 'stock_restricted_shares'
    else:
        collection_name = f'stock_restricted_shares_{market}'
    # 检查集合是否存在
    db = db_handler.mongo_client[config["MONGO_DB"]]
    existing_collections = db.list_collection_names()
    if collection_name not in existing_collections:
        raise ValueError(f"传入的market参数：'{market}'不合法或暂不支持，请尝试当前支持的市场如'cn'")

    result = db_handler.mongo_find(config["MONGO_DB"], collection_name, query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_holder_number(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    从 stock_holder_number 集合中读取股东户数数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段

    返回:
        pd.DataFrame: 包含查询结果的DataFrame，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）
    if symbol is not None:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        projection = {field: 1 for field in fields}
        # 确保包含 symbol 和 date
        projection.setdefault('symbol', 1)
        projection.setdefault('date', 1)

    # 始终排除 _id 字段
    if projection is None:
        projection = {'_id': 0}
    else:
        projection['_id'] = 0

    result = db_handler.mongo_find(config["MONGO_DB"], "stock_holder_number", query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_main_shareholder(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        start_rank: Optional[int] = None,
        end_rank: Optional[int] = None,
        stock_type: Optional[str] = None,
        market: Optional[str] = "cn",
        fields: Optional[List[str]] = None
)-> pd.DataFrame:
    """
    从 stock_main_holder 集合中读取主要股东数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        start_rank: 起始排名，如1（可选）
        end_rank: 结束排名，如10（可选）
        stock_type: 股票类型，如 "total"（可选）
        market: 所查询的市场，'cn' 或其他值（如 'en'），为None时默认查询 'cn' 市场
        fields: 需要返回的字段列表，如果为None则返回所有字段

    返回:
        pd.DataFrame: 包含查询结果的DataFrame，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）
    if symbol is not None:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理排名范围参数
    rank_query = {}
    if start_rank is not None:
        if not isinstance(start_rank, int) or start_rank < 1:
            raise ValueError("start_rank 必须是大于0的整数")
        rank_query['$gte'] = start_rank

    if end_rank is not None:
        if not isinstance(end_rank, int) or end_rank < 1:
            raise ValueError("end_rank 必须是大于0的整数")
        rank_query['$lte'] = end_rank

    # 如果有排名条件，添加到查询中
    if rank_query:
        query['rank'] = rank_query

    # 处理股票类型参数
    if stock_type is not None:
        query['stock_type'] = stock_type

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        projection = {field: 1 for field in fields}
        projection['_id'] = 0  # 默认不返回 _id
        # 确保包含 symbol 和 date
        projection.setdefault('symbol', 1)
        projection.setdefault('date', 1)
    else:
        # 当 fields 为 None 时，也要排除 _id 字段
        projection = {'_id': 0}

    # 处理 market 参数，确定查询的集合名称
    if market == 'cn':
        collection_name = 'stock_main_holder'
    else:
        raise ValueError(f"传入的market参数：'{market}'不合法或暂不支持，请尝试当前支持的市场如'cn'")

    # 检查集合是否存在
    result = db_handler.mongo_find(config["MONGO_DB"], collection_name, query, projection)
    result_df = pd.DataFrame(result)
    return result_df



def get_stock_special_treatment(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        start_change_date: Optional[str] = None,
        end_change_date: Optional[str] = None,
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    从 stock_special_treatment 集合中读取股票特殊处理数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        start_change_date: 开始变更日期字符串，格式如 "20250718"（可选）
        end_change_date: 结束变更日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段

    返回:
        pd.DataFrame: 包含查询结果的DataFrame，每个结果必定包含 symbol、date 和 change_date 字段

    异常:
        ValueError: 当日期格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）
    if symbol is not None:
        # 处理列表情况
        if isinstance(symbol, list):
            # 过滤掉空字符串和None值
            filtered_symbols = [s for s in symbol if s is not None and s != '']
            if filtered_symbols:  # 只有当有过滤后的有效值时才添加查询条件
                query['symbol'] = {'$in': filtered_symbols}
            # 如果过滤后没有有效值，则不添加symbol查询条件，等同于查询所有symbol
        else:
            # 处理单个值情况
            if symbol != '':  # 空字符串不添加查询条件
                query['symbol'] = symbol
            # 空字符串则不添加symbol查询条件，等同于查询所有symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None and start_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None and end_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理变更日期范围参数
    change_date_query = {}
    if start_change_date is not None and start_change_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            change_date_query['$gte'] = start_change_date
        except ValueError:
            raise ValueError("start_change_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_change_date is not None and end_change_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            change_date_query['$lte'] = end_change_date
        except ValueError:
            raise ValueError("end_change_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有变更日期条件，添加到查询中
    if change_date_query:
        query['change_date'] = change_date_query

    # 处理 fields 参数，确保包含 symbol、date 和 change_date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        # 过滤掉空字符串和None值
        filtered_fields = [f for f in fields if f is not None and f != '']
        if filtered_fields:
            projection = {field: 1 for field in filtered_fields}
            # 确保包含关键字段
            projection.setdefault('symbol', 1)
            projection.setdefault('date', 1)
            projection.setdefault('change_date', 1)

    # 始终排除 _id 字段
    if projection is None:
        projection = {'_id': 0}
    else:
        projection['_id'] = 0

    result = db_handler.mongo_find(config["MONGO_DB"], "stock_special_treatment", query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_stock_flow_1m(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        time_zone: Optional[tuple] = None,
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    从 stock_flow_1m_market 集合中读取股票资金流分钟级数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        time_zone: 时间段过滤，格式为("HH:MM", "HH:MM")，例如("09:30", "15:00")，默认为None
        fields: 需要返回的字段列表，如果为None则返回所有字段

    返回:
        pd.DataFrame: 包含查询结果的DataFrame，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当日期或时间格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）
    if symbol is not None:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol

    # 处理日期范围参数
    if start_date is not None or end_date is not None:
        # 由于数据库中的date字段是ISODate格式，我们需要使用$expr和$dateToString来提取日期部分
        date_conditions = []
        
        if start_date is not None:
            try:
                # 验证日期格式
                if len(start_date) != 8 or not start_date.isdigit():
                    raise ValueError("日期格式无效")
                date_conditions.append({'$gte': [{'$dateToString': {'format': '%Y%m%d', 'date': '$date'}}, start_date]})
            except ValueError:
                raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

        if end_date is not None:
            try:
                # 验证日期格式
                if len(end_date) != 8 or not end_date.isdigit():
                    raise ValueError("日期格式无效")
                date_conditions.append({'$lte': [{'$dateToString': {'format': '%Y%m%d', 'date': '$date'}}, end_date]})
            except ValueError:
                raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")
        
        # 如果有日期条件，添加到查询中
        if date_conditions:
            if len(date_conditions) == 1:
                query['$expr'] = date_conditions[0]
            else:
                query['$expr'] = {'$and': date_conditions}

    # 处理time_zone参数
    if time_zone:
        if len(time_zone) != 2:
            raise ValueError("time_zone参数必须是一个包含两个元素的元组，格式为('HH:MM', 'HH:MM')")
        
        start_timezone, end_timezone = time_zone
        
        # 将HH:MM格式转换为HHMM格式
        def time_to_hhmm(time_str):
            if ':' in time_str:
                return time_str.replace(':', '')
            return time_str
        
        start_hhmm = time_to_hhmm(start_timezone)
        end_hhmm = time_to_hhmm(end_timezone)
        
        # 由于数据库中的date字段是ISODate格式，我们需要使用$expr和$dateToString来提取时间部分
        # 构建时间条件
        if start_hhmm > end_hhmm:
            # 跨午夜的情况，使用$or条件
            time_conditions = [
                {'$and': [
                    {'$gte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, start_hhmm]},
                    {'$lte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, '2359']}
                ]},
                {'$and': [
                    {'$gte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, '0000']},
                    {'$lte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, end_hhmm]}
                ]}
            ]
        else:
            # 正常情况，在同一天内
            time_conditions = [
                {'$gte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, start_hhmm]},
                {'$lte': [{'$dateToString': {'format': '%H%M', 'date': '$date'}}, end_hhmm]}
            ]
        
        # 合并日期和时间条件
        if '$expr' in query:
            # 如果已经有日期条件，需要合并
            existing_expr = query['$expr']
            if start_hhmm > end_hhmm:
                # 跨午夜情况
                query['$expr'] = {'$and': [existing_expr, {'$or': time_conditions}]}
            else:
                # 正常情况
                query['$expr'] = {'$and': [existing_expr] + time_conditions}
        else:
            # 没有日期条件，直接设置时间条件
            if start_hhmm > end_hhmm:
                query['$expr'] = {'$or': time_conditions}
            else:
                query['$expr'] = {'$and': time_conditions}

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        projection = {field: 1 for field in fields}
        projection['_id'] = 0  # 默认不返回 _id
        # 确保包含关键字段
        projection.setdefault('symbol', 1)
        projection.setdefault('date', 1)
    
    result = db_handler.mongo_find(config["MONGO_DB"], "stock_flow_1m_market", query, projection)
    result_df = pd.DataFrame(result)
    return result_df

def get_block_trade(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    从 stock_block_trade 集合中读取大宗交易数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段
               可用字段: symbol, date, price, volume, amount, buyer, seller, sequence_id

    返回:
        pd.DataFrame: 包含查询结果的DataFrame，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）- 修复空值处理逻辑
    if symbol is not None:
        # 处理列表情况
        if isinstance(symbol, list):
            # 过滤掉空字符串和None值
            filtered_symbols = [s for s in symbol if s is not None and s != '']
            if filtered_symbols:  # 只有当有过滤后的有效值时才添加查询条件
                query['symbol'] = {'$in': filtered_symbols}
            # 如果过滤后没有有效值，则不添加symbol查询条件，等同于查询所有symbol
        else:
            # 处理单个值情况
            if symbol != '':  # 空字符串不添加查询条件
                query['symbol'] = symbol
            # 空字符串则不添加symbol查询条件，等同于查询所有symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None and start_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None and end_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        # 过滤掉空字符串和None值
        filtered_fields = [f for f in fields if f is not None and f != '']
        if filtered_fields:
            projection = {field: 1 for field in filtered_fields}
            projection['_id'] = 0  # 默认不返回 _id
            # 确保包含 symbol 和 date
            projection.setdefault('symbol', 1)
            projection.setdefault('date', 1)

    result = db_handler.mongo_find(config["MONGO_DB"], "stock_block_trade", query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_factor_restored(symbol: Optional[Union[str, List[str]]] = None,
                       start_date: Optional[str] = None,
                       end_date: Optional[str] = None,
                       fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取复权因子数据

    参数：
        symbol (str or List[str], 可选): 股票代码，可以是单个字符串或字符串列表，默认为空，返回所有。
        start_date (str, 可选): 起始日期，格式为"YYYYMMDD"，默认为空。
        end_date (str, 可选): 结束日期，格式为"YYYYMMDD"，默认为空。
        fields (List[str], 可选): 需要返回的字段列表，如果为None则返回所有字段。

    返回：
        pd.DataFrame: 包含查询结果的DataFrame，每个结果必定包含 symbol 和 ex_date 字段

    异常：
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）
    if symbol is not None:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None:
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['ex_date'] = date_query

    # 处理 fields 参数，确保包含 symbol 和 ex_date
    projection = {'_id': 0}  # 默认不返回 _id
    db_handler = DatabaseHandler(config)
    if fields:
        projection.update({field: 1 for field in fields})
        # 确保包含 symbol 和 ex_date
        projection.setdefault('symbol', 1)
        projection.setdefault('ex_date', 1)
    # 如果 fields 为 None，则返回所有字段但不包含 _id

    result = db_handler.mongo_find(config["MONGO_DB"], "factor_restored", query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_stock_shares(
        symbol: Optional[Union[str, List[str]]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    获取股票股本数据

    参数:
        symbol: 股票代码，可以是单个字符串或字符串列表（可选）
        start_date: 开始日期字符串，格式如 "20250718"（可选）
        end_date: 结束日期字符串，格式如 "20250720"（可选）
        fields: 需要返回的字段列表，如果为None则返回所有字段

    返回:
        包含查询结果的DataFrame，每个结果必定包含 symbol 和 date 字段

    异常:
        ValueError: 当 start_date 或 end_date 格式无效时
    """
    # 构建查询条件
    query = {}

    # 处理 symbol 参数（可选）
    if symbol is not None:
        # 处理列表情况
        if isinstance(symbol, list):
            # 过滤掉空字符串和None值
            filtered_symbols = [s for s in symbol if s is not None and s != '']
            if filtered_symbols:  # 只有当有过滤后的有效值时才添加查询条件
                query['symbol'] = {'$in': filtered_symbols}
            # 如果过滤后没有有效值，则不添加symbol查询条件，等同于查询所有symbol
        else:
            # 处理单个值情况
            if symbol != '':  # 空字符串不添加查询条件
                query['symbol'] = symbol
            # 空字符串则不添加symbol查询条件，等同于查询所有symbol

    # 处理日期范围参数
    date_query = {}
    if start_date is not None and start_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$gte'] = start_date
        except ValueError:
            raise ValueError("start_date 格式无效，应为 'YYYYMMDD' 格式")

    if end_date is not None and end_date != '':
        try:
            # 验证日期格式并转换为可比较格式
            date_query['$lte'] = end_date
        except ValueError:
            raise ValueError("end_date 格式无效，应为 'YYYYMMDD' 格式")

    # 如果有日期条件，添加到查询中
    if date_query:
        query['date'] = date_query

    # 处理 fields 参数，确保包含 symbol 和 date
    projection = None
    db_handler = DatabaseHandler(config)
    if fields:
        # 过滤掉空字符串和None值
        filtered_fields = [f for f in fields if f is not None and f != '']
        if filtered_fields:
            projection = {field: 1 for field in filtered_fields}
            projection['_id'] = 0  # 默认不返回 _id
            # 确保包含 symbol 和 date
            projection.setdefault('symbol', 1)
            projection.setdefault('date', 1)

    result = db_handler.mongo_find(config["MONGO_DB"], "stock_shares", query, projection)
    result_df = pd.DataFrame(result)
    return result_df


def get_trading_stock_list(date: Optional[Union[str, List[str]]] = None) -> pd.DataFrame:
    """
    获取指定日期的在售股票列表

    参数:
        date: 日期，可以是单个字符串或字符串列表，格式如 "20250101"（可选）
              如果不传则获取最新一天的数据

    返回:
        pd.DataFrame: 指定日期的在售股票列表（trade_status为0的股票）
    """
    db_handler = DatabaseHandler(config)
    query = {}
    
    # 添加trade_status过滤条件
    query["trade_status"] = 0
    
    # 处理日期参数
    if date is not None:
        if isinstance(date, str):
            query["date"] = date
        elif isinstance(date, list):
            query["date"] = {"$in": date}
        else:
            raise ValueError("date 参数必须为字符串或字符串列表")
    else:
        # 获取最新日期的数据
        # 首先查询最新的日期
        latest_date_result = db_handler.mongo_find(
            config["MONGO_DB"], 
            "stock_market", 
            {"trade_status": 0}, 
            {"date": 1, "_id": 0}
        )
        if latest_date_result:
            dates = [doc["date"] for doc in latest_date_result if "date" in doc]
            if dates:
                latest_date = max(dates)
                query["date"] = latest_date
    
    # 设置返回字段（返回所有字段，除了_id）
    projection = {"_id": 0,"symbol":1,"date":1}
    
    result = db_handler.mongo_find(config["MONGO_DB"], "stock_market", query, projection)
    result_df = pd.DataFrame(result)
    
    # 排序：先按日期降序，再按symbol升序
    if not result_df.empty:
        sort_columns = []
        sort_ascending = []
        
        if "date" in result_df.columns:
            sort_columns.append("date")
            sort_ascending.append(False)  # 日期降序
            
        if "symbol" in result_df.columns:
            sort_columns.append("symbol")
            sort_ascending.append(True)   # symbol升序
            
        if sort_columns:
            result_df = result_df.sort_values(by=sort_columns, ascending=sort_ascending)
            result_df = result_df.reset_index(drop=True)
    
    return result_df
