from typing import Optional, Union, List
import pandas as pd
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_financial_forecast(
        symbol: Optional[Union[str, List[str]]] = None,
        info_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取业绩预告

    参数：
        symbol: 股票代码，如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，默认为None返回所有
        fields: 需要返回的字段列表，默认为None返回全部字段
        info_date: 信息发布日期，格式"YYYYMMDD"
        end_date: 业绩截止日期，格式"YYYYMMDD"

    返回：
        pd.DataFrame: 指定股票的业绩预告信息。
    """
    query = {}
    if symbol is not None:
        if isinstance(symbol, list):
            query["symbol"] = {"$in": symbol}
        else:
            query["symbol"] = symbol
    if info_date:
        query["info_date"] = info_date
    if end_date:
        query["end_date"] = end_date

    db_handler = DatabaseHandler(config)

    projection = None
    if fields:
        # 确保必要字段一定在返回字段中
        required_fields = ["symbol", "info_date"]
        for field in required_fields:
            if field not in fields:
                fields.append(field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0

    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "financial_forecast", query, projection))
    if not result.empty and "symbol" in result.columns and "info_date" in result.columns :
        result = result.sort_values(by=["symbol", "info_date"], ascending=[True, False])
        result = result.reset_index(drop=True)

    return result


def get_financial_performance(
        symbol: Optional[Union[str, List[str]]] = None,
        info_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fields: Optional[List[str]] = None) -> pd.DataFrame:
    """
    获取业绩快报

    参数：
        symbol: 股票代码，如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，默认为None返回所有
        fields: 需要返回的字段列表，默认为None返回全部字段
        info_date: 信息发布日期，格式"YYYYMMDD"
        end_date: 业绩截止日期，格式"YYYYMMDD"

    返回：
        pd.DataFrame: 指定股票的业绩快报信息。
    """
    query = {}
    if symbol is not None:
        if isinstance(symbol, list):
            query["symbol"] = {"$in": symbol}
        else:
            query["symbol"] = symbol
    if info_date:
        query["info_date"] = info_date
    if end_date:
        query["end_date"] = end_date

    db_handler = DatabaseHandler(config)

    projection = None
    if fields:
        # 确保必要字段一定在返回字段中
        required_fields = ["symbol", "info_date"]
        for field in required_fields:
            if field not in fields:
                fields.append(field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0

    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "financial_performance", query, projection))
    #排序：按symbol升序
    if not result.empty and "symbol" in result.columns:
        result = result.sort_values(by="symbol", ascending=True)
        result = result.reset_index(drop=True)

    return result


def get_financial_ex(
        symbol: Optional[Union[str, List[str]]] = None,
        fields: Optional[List[str]] = None,
        start_quarter: Optional[str] = None,
        end_quarter: Optional[str] = None,
        date: Optional[str] = None,
        is_latest: bool = True) -> pd.DataFrame:
    """
    获取季度财务报告

    参数：
        symbol: 股票代码，如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，默认为None返回所有
        fields: 需要返回的字段列表，默认为None返回全部字段
        start_quarter: 起始季度，格式如"2021q1"
        end_quarter: 结束季度，格式如"2023q4"
        date: 日期过滤，格式为"YYYYMMDD"，返回该日期及之前的数据
        is_latest: 是否只返回最新数据，默认为True。为True时返回每个symbol和quarter组合的最新一条数据（date最大），为False时返回所有数据

    返回：
        pd.DataFrame: 指定股票的季度财务报告信息。
    """
    query = {}
    if symbol is not None:
        if isinstance(symbol, list):
            query["symbol"] = {"$in": symbol}
        else:
            query["symbol"] = symbol
    if start_quarter and end_quarter:
        query["quarter"] = {"$gte": start_quarter, "$lte": end_quarter}
    elif start_quarter:
        query["quarter"] = {"$gte": start_quarter}
    elif end_quarter:
        query["quarter"] = {"$lte": end_quarter}
    
    if date:
        query["date"] = {"$lte": date}

    db_handler = DatabaseHandler(config)

    projection = None
    if fields:
        # 确保必要字段一定在返回字段中
        required_fields = ["symbol", "quarter", "date"]
        for field in required_fields:
            if field not in fields:
                fields.append(field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0

    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "financial_ex", query, projection))
    
    # 如果需要返回最新数据，则对每个symbol和quarter组合保留date最大的记录
    if is_latest and not result.empty and "date" in result.columns:
        result = result.loc[result.groupby(["symbol", "quarter"])["date"].idxmax()]
        result = result.reset_index(drop=True)
    
    # 排序：先按symbol升序，再按quarter降序
    if not result.empty and "symbol" in result.columns and "quarter" in result.columns:
        result = result.sort_values(by=["symbol", "quarter"], ascending=[True, False])
        result = result.reset_index(drop=True)

    return result
