from typing import Optional, List, Union
import pandas as pd
from ..common.handlers.database_handler import DatabaseHandler
from ..common.config import config


def get_abnormal(
    symbol: Optional[Union[str, List[str]]] = None,
    type: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    获取龙虎榜每日明细
    
    Args:
        symbol: 股票代码，如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，默认为None返回所有
        type: 异常类型
        start_date: 开始日期，格式 "YYYYMMDD"，默认为None
        end_date: 结束日期，格式 "YYYYMMDD"，默认为None
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含股票异常数据的DataFrame，按日期降序排列
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if symbol:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol
    if type:
        if isinstance(type, list):
            query['type'] = {'$in': type}
        else:
            query['type'] = type
    if start_date or end_date:
        query['date'] = {}
        if start_date:
            query['date']['$gte'] = start_date
        if end_date:
            query['date']['$lte'] = end_date
    
    # 构建投影
    projection = None
    if fields:
        # 确保 symbol、date 和 type 一定在返回字段中
        required_fields = ["symbol", "date", "type"]
        for field in required_fields:
            if field not in fields:
                fields.append(field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0
    
    # 执行查询
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "abnormal", query, projection))
    
    # 排序：先按symbol升序，date降序,type升序
    if not result.empty and "symbol" in result.columns and "date" in result.columns:
        result = result.sort_values(by=["symbol","date"], ascending=[True,False])
        result = result.reset_index(drop=True)

    
    return result


def get_abnormal_detail(
    symbol: Optional[Union[str, List[str]]] = None,
    type: Optional[Union[str, List[str]]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    side: Optional[str] = None,
    fields: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    获取股票异常明细数据
    
    Args:
        symbol: 股票代码，如 "000001.SZ" 或 ["000001.SZ", "000002.SZ"]，默认为None返回所有
        type: 异常类型
        start_date: 开始日期，格式 "YYYYMMDD"，默认为None
        end_date: 结束日期，格式 "YYYYMMDD"，默认为None
        side: 买卖方向，可选值为 "buy" 或 "sell"，默认为None返回所有
        fields: 需要返回的字段列表，默认为None返回全部字段
    
    Returns:
        DataFrame: 包含股票异常明细数据的DataFrame，按日期降序排列
    """
    db_handler = DatabaseHandler(config)
    
    # 构建查询条件
    query = {}
    if symbol:
        if isinstance(symbol, list):
            query['symbol'] = {'$in': symbol}
        else:
            query['symbol'] = symbol
    if type:
        if isinstance(type, list):
            query['type'] = {'$in': type}
        else:
            query['type'] = type
    if side:
        query['side'] = side
    if start_date or end_date:
        query['date'] = {}
        if start_date:
            query['date']['$gte'] = start_date
        if end_date:
            query['date']['$lte'] = end_date
    
    # 构建投影
    projection = None
    if fields:
        # 确保必要字段一定在返回字段中
        required_fields = ["symbol", "date", "type", "side"]
        for field in required_fields:
            if field not in fields:
                fields.append(field)
        projection = {field: 1 for field in fields}
    projection = projection or {}
    projection["_id"] = 0
    
    # 执行查询
    result = pd.DataFrame(db_handler.mongo_find(config["MONGO_DB"], "abnormal_detail", query, projection))
    
    # 如果用户指定了字段，只返回用户指定的字段（需要检查字段是否存在）
    if fields and not result.empty:
        # 获取实际存在的字段
        existing_fields = [field for field in fields if field in result.columns]
        # 添加必要的字段（如果它们不在fields中但存在于结果中）
        for field in ["date"]:
            if field not in existing_fields and field in result.columns:
                existing_fields.append(field)
        result = result[existing_fields]
    
    # 排序：先按symbol升序，按日期降序排列
    if not result.empty and all(col in result.columns for col in ["symbol", "date", "rank"]):
        result = result.sort_values(by=["symbol","date","rank"], ascending=[True,False,True])
        result = result.reset_index(drop=True)
    
    return result


def get_abnormal_types() -> pd.DataFrame:
    """
    获取所有异常类型
    
    Returns:
        DataFrame: 包含所有异常类型的DataFrame
    """
    db_handler = DatabaseHandler(config)
    
    # 聚合查询获取所有不同的type值
    pipeline = [
        {"$group": {"_id": "$type"}},
        {"$project": {"type": "$_id", "_id": 0}},
        {"$sort": {"type": 1}},
    ]
    
    result = pd.DataFrame(db_handler.mongo_client[config["MONGO_DB"]]["abnormal"].aggregate(pipeline))
    result = result.reset_index(drop=True)
    return result


def get_abnormal_stocks(date: str, type: Optional[Union[str, List[str]]] = None) -> pd.DataFrame:
    """
    获取指定日期的异常股票列表
    
    Args:
        date: 日期，格式 "YYYYMMDD"
        type: 异常类型
    
    Returns:
        DataFrame: 包含指定日期异常股票的DataFrame
    """
    return get_abnormal(start_date=date, end_date=date, type=type, fields=["symbol", "date", "type", "reason"])