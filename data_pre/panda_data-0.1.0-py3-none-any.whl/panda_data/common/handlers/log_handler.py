import logging
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
from ..config import config
from .database_handler import DatabaseHandler

import threading
import time
import os

class LogBatchManager:
    """日志批量管理器，缓存日志并定期批量写入数据库"""
    
    _instance = None
    _lock = threading.Lock()
    
    @classmethod
    def get_instance(cls):
        """单例模式获取实例"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = LogBatchManager()
        return cls._instance
    
    def __init__(self):
        """初始化批量管理器"""
        self.log_buffer = {}  # 按task_id分组的日志缓存
        self.buffer_lock = threading.Lock()
        self.db_handler = DatabaseHandler(config)
        self.flush_interval = 5  # 刷新间隔（秒）
        self.max_buffer_size = 50  # 每个任务的最大缓存日志数量
        
        # 启动后台线程定期刷新日志
        self.stop_flag = False
        self.flush_thread = threading.Thread(target=self._flush_loop)
        self.flush_thread.daemon = True
        self.flush_thread.start()
    
    def add_log(self, task_id: str, log_entry: Dict[str, Any]):
        """添加日志到缓存"""
        with self.buffer_lock:
            if task_id not in self.log_buffer:
                self.log_buffer[task_id] = []
            
            self.log_buffer[task_id].append(log_entry)
            
            # 如果缓存达到阈值，立即刷新
            if len(self.log_buffer[task_id]) >= self.max_buffer_size:
                self._flush_task_logs(task_id)
    
    def _flush_loop(self):
        """定期刷新日志的后台线程"""
        while not self.stop_flag:
            time.sleep(self.flush_interval)
            self.flush_all()
    
    def _flush_task_logs(self, task_id: str):
        """刷新指定任务的日志到数据库"""
        logs_to_save = []
        with self.buffer_lock:
            if task_id in self.log_buffer and self.log_buffer[task_id]:
                logs_to_save = self.log_buffer[task_id]
                self.log_buffer[task_id] = []
        
        if logs_to_save:
            try:
                for log in logs_to_save:
                    # 构建日志记录
                    log_record = {
                        "log_id": str(uuid.uuid4()),
                        "task_id": log["task_id"],
                        "factor_id": log["factor_id"],
                        "message": log["message"],
                        "level": log["level"],
                        "timestamp": log["timestamp"],
                        "stage": log.get("stage", "default"),
                        "details": log.get("details"),
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat()
                    }
                    
                    # 直接插入到数据库
                    self.db_handler.mongo_insert("api", "factor_analysis_stage_logs", log_record)
                
                # 更新任务状态
                if len(logs_to_save) > 0:
                    latest_log = logs_to_save[-1]
                    self.db_handler.mongo_update(
                        "api",
                        "tasks",
                        {"task_id": latest_log["task_id"]},
                        {
                            "current_stage": latest_log.get("stage", "unknown"),
                            "last_log_message": latest_log["message"],
                            "last_log_time": latest_log["timestamp"],
                            "last_log_level": latest_log["level"],
                            "updated_at": datetime.now().isoformat()
                        }
                    )
            except Exception as e:
                print(f"Error saving batch logs: {e}")
    
    def flush_all(self):
        """刷新所有任务的日志"""
        with self.buffer_lock:
            task_ids = list(self.log_buffer.keys())
        
        for task_id in task_ids:
            self._flush_task_logs(task_id)
    
    def shutdown(self):
        """关闭批量管理器"""
        self.stop_flag = True
        if self.flush_thread.is_alive():
            self.flush_thread.join(timeout=10)
        self.flush_all()  # 确保所有日志都被保存

class FactorAnalysisLogHandler(logging.Handler):
    """因子分析日志处理器，将日志保存到MongoDB"""

    def __init__(self, task_id: str, factor_id: str, level=logging.INFO):
        """
        初始化日志处理器
        
        参数:
        - task_id: 任务ID
        - factor_id: 因子ID
        - level: 日志级别
        """
        super().__init__(level)
        self.task_id = task_id
        self.factor_id = factor_id
        self.batch_manager = LogBatchManager.get_instance()
        
        # 创建格式化器
        self.formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        
    def emit(self, record):
        """记录日志到MongoDB"""
        try:
            # 获取extra中的信息
            stage = getattr(record, 'stage', 'default')
            details = getattr(record, 'details', {})
            
            # 记录主要日志
            log_entry = {
                "log_id": str(uuid.uuid4()),
                "task_id": self.task_id,
                "factor_id": self.factor_id,
                "level": record.levelname,
                "message": self.format(record),
                "timestamp": datetime.now().isoformat(),
                "stage": stage
            }
            
            # 添加到批量管理器
            self.batch_manager.add_log(self.task_id, log_entry)
            
            # 如果有详细信息，为每个字段创建单独的debug日志
            if details:
                for key, value in details.items():
                    debug_entry = {
                        "log_id": str(uuid.uuid4()),
                        "task_id": self.task_id,
                        "factor_id": self.factor_id,
                        "level": "DEBUG",
                        "message": f"{key}: {value}",
                        "timestamp": datetime.now().isoformat(),
                        "stage": stage
                    }
                    self.batch_manager.add_log(self.task_id, debug_entry)
            
            # 为保持实时性，重要日志立即写入
            if record.levelname in ("ERROR", "CRITICAL", "WARNING"):
                self.batch_manager.flush_all()
                
        except Exception as e:
            # 避免日志处理异常导致应用崩溃
            print(f"Error saving log to MongoDB: {e}")
            
def get_factor_logger(task_id: str, factor_id: str) -> logging.Logger:
    """
    获取因子分析专用的日志记录器
    
    参数:
    - task_id: 任务ID
    - factor_id: 因子ID
    
    返回:
    - logging.Logger: 配置好的日志记录器
    """
    # 创建日志记录器
    logger = logging.getLogger(f"factor_analysis_{task_id}")
    logger.setLevel(logging.DEBUG)  # 设置日志级别为DEBUG
    
    # 如果已经有处理器，不重复添加
    if logger.handlers:
        return logger
        
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)  # 控制台只显示INFO及以上级别
    console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # 创建MongoDB处理器
    mongo_handler = FactorAnalysisLogHandler(
        task_id=task_id,
        factor_id=factor_id
    )
    mongo_handler.setLevel(logging.DEBUG)  # MongoDB记录所有级别
    mongo_formatter = logging.Formatter('%(message)s')
    mongo_handler.setFormatter(mongo_formatter)
    logger.addHandler(mongo_handler)
    
    return logger