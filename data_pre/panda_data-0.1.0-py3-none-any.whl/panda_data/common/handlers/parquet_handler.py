#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Parquet文件读取工具类
提供统一的parquet数据查询接口，支持字段选择、日期范围和条件过滤
"""

import duckdb
import pandas as pd
import os
from typing import List, Optional, Dict, Any
from pathlib import Path


class ParquetHandler:
    """
    Parquet文件读取工具类
    
    提供统一的parquet数据查询接口，支持：
    - 根据日期范围动态查找parquet文件
    - 字段选择和过滤
    - 股票代码过滤
    - 自定义条件过滤
    - 跨月份数据查询
    """
    
    def __init__(self, base_dir: str):
        """
        初始化ParquetHandler
        
        Args:
            base_dir (str): parquet文件的基础目录路径
        """
        self.base_dir = base_dir
        self._available_columns_cache = {}  # 缓存列信息
    
    def get_parquet_columns(self, parquet_path: str) -> List[str]:
        """
        获取parquet文件中的列名
        
        Args:
            parquet_path (str): parquet文件路径
        
        Returns:
            List[str]: 列名列表
        """
        try:
            con = duckdb.connect()
            # 使用LIMIT 0来获取列信息而不实际读取数据
            df_sample = con.execute(f"SELECT * FROM read_parquet('{parquet_path}') LIMIT 0").df()
            con.close()
            return list(df_sample.columns)
        except Exception as e:
            print(f"获取列信息时发生错误: {e}")
            return []
    
    def get_parquet_paths_by_date_range(self, start_date: str, end_date: str) -> List[str]:
        """
        根据日期范围获取对应的parquet文件路径列表
        
        Args:
            start_date (str): 开始日期，格式为'YYYYMMDD'，如'20250101'
            end_date (str): 结束日期，格式为'YYYYMMDD'，如'20250131'
        
        Returns:
            List[str]: parquet文件路径列表
        """
        paths = []
        
        try:
            # 验证输入参数
            if not start_date or not end_date:
                print(f"错误: start_date 或 end_date 不能为空，start_date={start_date}, end_date={end_date}")
                return []
            
            if not isinstance(start_date, str) or not isinstance(end_date, str):
                print(f"错误: start_date 和 end_date 必须是字符串类型，start_date={type(start_date)}, end_date={type(end_date)}")
                return []
            
            if len(start_date) < 6 or len(end_date) < 6:
                print(f"错误: 日期格式不正确，应为YYYYMMDD格式，start_date={start_date}, end_date={end_date}")
                return []
            
            # 从日期字符串中提取年月信息
            start_year_month = start_date[:6]  # 截取前6位，如'202501'
            end_year_month = end_date[:6]      # 截取前6位，如'202501'
            
            # 如果开始和结束日期在同一个月份
            if start_year_month == end_year_month:
                month_dir = f"month={start_year_month}"
                month_path = os.path.join(self.base_dir, month_dir)
                
                if os.path.exists(month_path):
                    for file in os.listdir(month_path):
                        if file.endswith('.parquet') and not file.startswith('._'):
                            file_path = os.path.join(month_path, file)
                            paths.append(file_path)
                # 静默处理：如果目录不存在，不打印日志，直接返回空列表
            else:
                # 如果跨月份，需要遍历多个月份
                current_year_month = start_year_month
                
                while current_year_month <= end_year_month:
                    month_dir = f"month={current_year_month}"
                    month_path = os.path.join(self.base_dir, month_dir)
                    
                    if os.path.exists(month_path):
                        for file in os.listdir(month_path):
                            if file.endswith('.parquet') and not file.startswith('._'):
                                file_path = os.path.join(month_path, file)
                                paths.append(file_path)
                    # 静默处理：如果目录不存在，跳过该月份，继续查找下一个月
                    
                    # 移动到下一个月
                    year = int(current_year_month[:4])
                    month = int(current_year_month[4:6])
                    
                    if month == 12:
                        year += 1
                        month = 1
                    else:
                        month += 1
                    
                    current_year_month = f"{year:04d}{month:02d}"
            
            return paths
            
        except Exception as e:
            print(f"构建parquet文件路径时发生错误: {e}")
            return []
    
    def query_data(self, start_date: str = None, end_date: str = None, columns: List[str] = None, 
                   symbols: List[str] = None, custom_conditions: List[str] = None) -> pd.DataFrame:
        """
        查询parquet数据
        
        Args:
            start_date (str): 开始日期，格式为'YYYYMMDD'，如'20250101'
            end_date (str): 结束日期，格式为'YYYYMMDD'，如'20250131'
            columns (List[str]): 要返回的字段列表，默认为None（返回所有字段）
            symbols (List[str]): 股票代码列表，如['000001.SZ', '000002.SZ']，默认为None（查询所有股票）
            custom_conditions (List[str]): 自定义过滤条件，如["client_deposits_mrq_0 > 1000"]，默认为None
        
        Returns:
            pandas.DataFrame: 查询结果数据框
        """
        # 验证和设置默认日期
        if not start_date or not end_date:
            from datetime import datetime
            today = datetime.now()
            if not start_date:
                start_date = today.strftime("%Y%m%d")
            if not end_date:
                end_date = today.strftime("%Y%m%d")
            print(f"使用默认日期范围: {start_date} 到 {end_date}")
        
        # 获取parquet文件路径
        parquet_paths = self.get_parquet_paths_by_date_range(start_date, end_date)
        
        if not parquet_paths:
            print("没有找到对应的parquet文件")
            return pd.DataFrame()
        
        # 如果columns为None，获取所有可用字段
        if columns is None:
            available_columns = self.get_parquet_columns(parquet_paths[0])
            columns = available_columns
            print(f"返回所有字段，共 {len(columns)} 个字段")
        else:
            # 验证指定的字段是否存在
            available_columns = self.get_parquet_columns(parquet_paths[0])
            print(f"parquet文件中的可用字段: {available_columns[:10]}...")  # 只显示前10个字段
            invalid_columns = [col for col in columns if col not in available_columns]
            if invalid_columns:
                print(f"警告: 以下字段不存在于parquet文件中: {invalid_columns}")
                # 只保留存在的字段
                columns = [col for col in columns if col in available_columns]
                if not columns:
                    print("没有有效的字段，使用默认字段 ['symbol', 'date']")
                    columns = ['symbol', 'date']
        
        # 将字段列表转换为SQL查询字符串
        columns_str = ', '.join(columns)
        
        # 构建WHERE条件
        where_conditions = []
        
        # 日期范围过滤
        where_conditions.append(f"date >= '{start_date}'")
        where_conditions.append(f"date <= '{end_date}'")
        
        # 股票代码过滤
        if symbols:
            # 确保symbols是字符串列表，而不是单个字符串
            if isinstance(symbols, str):
                symbols = [symbols]
            elif isinstance(symbols, (list, tuple)):
                # 确保列表中的每个元素都是字符串
                symbols = [str(s) for s in symbols]
            else:
                symbols = [str(symbols)]
            symbols_str = "', '".join(symbols)
            where_conditions.append(f"symbol IN ('{symbols_str}')")
        
        # 自定义条件
        if custom_conditions:
            where_conditions.extend(custom_conditions)
        
        where_clause = " WHERE " + " AND ".join(where_conditions)
        
        try:
            # 创建DuckDB连接
            con = duckdb.connect()
            
            # 构建UNION ALL查询来合并多个parquet文件
            
            # 构建UNION ALL查询来合并多个parquet文件
            union_queries = []
            for parquet_path in parquet_paths:
                query = f"SELECT {columns_str} FROM read_parquet('{parquet_path}'){where_clause}"
                union_queries.append(query)
            
            # 合并所有查询
            final_query = " UNION ALL ".join(union_queries)
            
            # 执行查询
            df = con.execute(final_query).df()
            
            # 关闭连接
            con.close()
            
            print(f"查询完成: 返回 {len(df)} 行数据，日期范围: {start_date} 到 {end_date}")
            return df
            
        except Exception as e:
            print(f"查询数据时发生错误: {e}")
            return pd.DataFrame()
    
    def get_available_columns(self, start_date: str = None, end_date: str = None) -> List[str]:
        """
        获取可用字段列表
        
        Args:
            start_date (str): 开始日期，用于确定parquet文件路径
            end_date (str): 结束日期，用于确定parquet文件路径
        
        Returns:
            List[str]: 可用字段列表
        """
        if start_date and end_date:
            parquet_paths = self.get_parquet_paths_by_date_range(start_date, end_date)
            if parquet_paths:
                return self.get_parquet_columns(parquet_paths[0])
        return []
    
    def query_by_symbol(self, symbol: str, start_date: str, end_date: str, 
                       columns: List[str] = None) -> pd.DataFrame:
        """
        查询单个股票的数据
        
        Args:
            symbol (str): 股票代码
            start_date (str): 开始日期，格式为'YYYYMMDD'
            end_date (str): 结束日期，格式为'YYYYMMDD'
            columns (List[str]): 要返回的字段列表
        
        Returns:
            pandas.DataFrame: 查询结果数据框
        """
        return self.query_data(start_date, end_date, columns, symbols=[symbol])
    
    def query_by_symbols(self, symbols: List[str], start_date: str, end_date: str, 
                        columns: List[str] = None) -> pd.DataFrame:
        """
        查询多个股票的数据
        
        Args:
            symbols (List[str]): 股票代码列表
            start_date (str): 开始日期，格式为'YYYYMMDD'
            end_date (str): 结束日期，格式为'YYYYMMDD'
            columns (List[str]): 要返回的字段列表
        
        Returns:
            pandas.DataFrame: 查询结果数据框
        """
        return self.query_data(start_date, end_date, columns, symbols=symbols)
    
    def query_with_conditions(self, start_date: str, end_date: str, columns: List[str] = None,
                             symbols: List[str] = None, conditions: List[str] = None) -> pd.DataFrame:
        """
        带条件查询数据
        
        Args:
            start_date (str): 开始日期，格式为'YYYYMMDD'
            end_date (str): 结束日期，格式为'YYYYMMDD'
            columns (List[str]): 要返回的字段列表
            symbols (List[str]): 股票代码列表
            conditions (List[str]): 过滤条件列表
        
        Returns:
            pandas.DataFrame: 查询结果数据框
        """
        return self.query_data(start_date, end_date, columns, symbols, conditions)
