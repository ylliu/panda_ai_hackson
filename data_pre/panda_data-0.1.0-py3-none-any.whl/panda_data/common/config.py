"""
配置模块，用于加载和管理配置信息
支持从配置文件和环境变量导入，环境变量优先级更高
"""
import os
import yaml
import logging
from pathlib import Path

# 获取logger
try:
    from panda_data.common.logger_config import logger
except ImportError:
    # 如果无法导入logger，创建一个基本的logger
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("config")

# 初始化配置变量config = None

def load_config():
    """加载配置文件，并从环境变量更新配置"""
    global config
    
    config = {}
    # MongoDB
    config["MONGO_USER"] = os.getenv("MONGO_USER", "songshu")
    config["MONGO_PASSWORD"] = os.getenv("MONGO_PASSWORD", "1q2w3e4R@")
    config["MONGO_URI"] = os.getenv("MONGO_URI",
                                    "dds-uf66047722c787541389-pub.mongodb.rds.aliyuncs.com:3717,dds-uf66047722c787542343-pub.mongodb.rds.aliyuncs.com:3717")
    config["MONGO_AUTH_DB"] = os.getenv("MONGO_AUTH_DB", "admin")
    config["MONGO_DB"] = os.getenv("MONGO_DB", "panda")
    config["MONGO_TYPE"] = os.getenv("MONGO_TYPE", "replica_set")
    config["MONGO_REPLICA_SET"] = os.getenv("MONGO_REPLICA_SET", "mgset-87730717")

    # 日志配置 Logging
    config["LOG_LEVEL"] = os.getenv("LOG_LEVEL", "DEBUG")
    config["log_file"] = os.getenv("LOG_FILE", "logs/data_cleaner.log")
    config["log_rotation"] = os.getenv("LOG_ROTATION", "1 MB")
    config["LOG_PATH"] = os.getenv("LOG_PATH", "~/log")

    # 数据输出路径配置
    config["factor_financial_parquet_path"] = os.getenv("factor_financial_parquet_path", "/nas/factor_financial")
    config["factor_base_post_parquet_path"] = os.getenv("factor_base_post_parquet_path", "/nas/factor_base")
    config["future_market_post_parquet_path"] = os.getenv("future_market_post_parquet_path", "/nas/future_market")
    config["index_component_us_parquet_path"] = os.getenv("index_component_us_parquet_path", "/nas/index_component_us")
    config["future_market_post_parquet_path"] = os.getenv("future_market_post_parquet_path", "/nas/future_market")
    config["parquet_path"] = os.getenv("parquet_path", "/nas/parquet")

    return config


def get_config():
    """
    获取配置对象，如果配置未加载则先加载配置

    Returns:
        dict: 配置信息字典
    """
    global config
    if config is None:
        config = load_config()
    return config


# 初始加载配置
try:
    config = load_config()
    # logger.info(f"初始化配置成功: {config}")  # 已禁用初始化配置日志
except Exception as e:
    logger.error(f"初始化配置失败: {str(e)}")
    # 不在初始化时抛出异常，留到实际使用时再处理
