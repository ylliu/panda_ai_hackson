from panda_data.common.config import config

parquet_path = config["parquet_path"]

# 港股行情不复权
STOCK_MAEKET_HK=parquet_path + "/stock_market_hk"
# 港股基础因子后复权
FACTOR_BASE_POST_HK=parquet_path + "/factor_base_post_hk"

# A股行情不复权
STOCK_MARKET=parquet_path + "/stock_market"
# A股基础因子后复权
FACTOR_BASE_POST=parquet_path + "/factor_base_post"


# 美股行情不复权
STOCK_MAEKET_US=parquet_path + "/stock_market_us"
# 美股基础因子后复权
FACTOR_BASE_POST_US=parquet_path + "/factor_base_post_us"
# 美股成分股数据
INDEX_COMPONENT_US=parquet_path + "/index_component_us"