def init(username=None, password=None, addr=("", 1), *_, **kwargs):
    return None