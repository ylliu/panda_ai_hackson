from . import api
from . import client

# Import all readers
from .api import kline_reader
# from .api import factor_reader
from .api import fund_reader
from .api import index_reader
from .api import concept_reader
from .api import financial_reader
from .api import stock_reader
from .api import securities_margin_reader
from .api import stock_connect_reader
from .api import buy_back_reader
from .api import consensus_reader
from .api import abnormal_reader
from .api import calendar_reader
from .api import industry_reader
from .api import future_reader
from .api.factor_reader_stock import get_stock_factor_base

# init
init = client.init()

# stock_kline
get_stock_detail = kline_reader.get_stock_detail
get_all_symbols = kline_reader.get_all_symbols
get_market_data = kline_reader.get_market_data
get_market_min_data = kline_reader.get_market_min_data
get_stock_connect = stock_connect_reader.get_stock_connect

# factor
get_stock_factor_base=api.factor_reader_stock.get_stock_factor_base
# get_custom_factor = api.factor_reader.get_custom_factor
# create_factor_from_class = api.factor_reader.create_factor_from_class
# create_factor_from_formula = api.factor_reader.create_factor_from_formula
# factor_result = api.factor_reader.factor_analysis
# get_factor = api.factor_reader.get_factor


# fund
get_all_funds = fund_reader.get_all_funds
get_fund_pro = fund_reader.get_fund_pro
get_fund_nav = fund_reader.get_fund_nav

# index
get_index_symbol = index_reader.get_index_symbol
get_index_indicator = index_reader.get_index_indicator
get_index_weights = index_reader.get_index_weights
get_index_stock = index_reader.get_index_stock
get_index_component_us = index_reader.get_index_component_us
get_index_list = index_reader.get_index_list
get_all_index_symbols = index_reader.get_all_index_symbols
get_index_1m_market = index_reader.get_index_1m_market

# industry
get_industry_stock = industry_reader.get_industry_stock
get_industry_list = industry_reader.get_industry_list
get_stock_industry = industry_reader.get_stock_industry

# concept
get_concept_list = concept_reader.get_concept_list
get_concept_stock = concept_reader.get_concept_stock

# financial
get_financial_ex = financial_reader.get_financial_ex
get_financial_performance = financial_reader.get_financial_performance
get_financial_forecast = financial_reader.get_financial_forecast

# stock
get_stock_flow = stock_reader.get_stock_flow
get_audit_opinion = stock_reader.get_audit_opinion
get_investor_activities = stock_reader.get_investor_activities
get_restricted_details = stock_reader.get_restricted_details
get_holder_number = stock_reader.get_holder_number
get_main_shareholder = stock_reader.get_main_shareholder
get_stock_special_treatment = stock_reader.get_stock_special_treatment
get_stock_flow_1m = stock_reader.get_stock_flow_1m
get_block_trade = stock_reader.get_block_trade
get_factor_restored = stock_reader.get_factor_restored
get_stock_shares = stock_reader.get_stock_shares
get_trading_stock_list = stock_reader.get_trading_stock_list

# future
get_future_list = future_reader.get_future_list
get_future_factor_post = future_reader.get_future_factor_post

#securities_margin
get_securities_margin = securities_margin_reader.get_securities_margin

#buyback
get_buy_back = buy_back_reader.get_buy_back

# consensus
get_consensus_report = consensus_reader.get_consensus_report

# abnormal
get_abnormal = abnormal_reader.get_abnormal
get_abnormal_detail = abnormal_reader.get_abnormal_detail
get_abnormal_types = abnormal_reader.get_abnormal_types
get_abnormal_stocks = abnormal_reader.get_abnormal_stocks

# calendar
get_trading_calendar = calendar_reader.get_trading_calendar
get_trading_days = calendar_reader.get_trading_days
get_non_trading_days = calendar_reader.get_non_trading_days
is_trading_day = calendar_reader.is_trading_day
get_previous_trading_date = calendar_reader.get_previous_trading_date
get_next_trading_date = calendar_reader.get_next_trading_date
get_trading_days_count = calendar_reader.get_trading_days_count
get_latest_trading_date = calendar_reader.get_latest_trading_date
get_trading_days_list = calendar_reader.get_trading_days_list